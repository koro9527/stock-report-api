import React, { useState, useCallback } from 'react';
import StockSearch from './components/StockSearch';
import AnalysisReport from './components/AnalysisReport';
import Charts from './components/Charts';
import { stockApi } from './services/stockApi';
import { analysisEngine } from './services/analysisEngine';
import { StockInfo, FinancialData, StockAnalysisReport } from './types/stock';

const App: React.FC = () => {
  const [stockInfo, setStockInfo] = useState<StockInfo | null>(null);
  const [historicalData, setHistoricalData] = useState<FinancialData[]>([]);
  const [report, setReport] = useState<StockAnalysisReport | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = useCallback(async (symbol: string) => {
    setLoading(true);
    setError(null);
    setHasSearched(true);

    try {
      // 获取股票基本信息
      const info = await stockApi.getStockInfo(symbol);
      setStockInfo(info);

      // 获取历史财务数据
      const history = await stockApi.getHistoricalFinancials(symbol, 5);
      setHistoricalData(history);

      // 执行18步分析
      const analysisResult = analysisEngine.analyzeStock(info, history);

      // 生成完整报告
      const fullReport = analysisEngine.generateReport(info, history, analysisResult);
      setReport(fullReport);

    } catch (err) {
      setError(err instanceof Error ? err.message : '获取数据失败，请检查股票代码是否正确');
    } finally {
      setLoading(false);
    }
  }, []);

  const handleReset = () => {
    setStockInfo(null);
    setHistoricalData([]);
    setReport(null);
    setError(null);
    setHasSearched(false);
  };

  return (
    <div className="app">
      {/* 头部导航 */}
      <header className="app-header">
        <div className="header-content">
          <div className="logo">
            <svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M3 3v18h18" />
              <path d="M18 9l-5-6-4 10-3-3" />
            </svg>
            <span>年报分析系统</span>
          </div>
          <nav className="nav-links">
            <a href="#home">首页</a>
            <a href="#about">关于</a>
            <a href="#contact">联系我们</a>
          </nav>
        </div>
      </header>

      {/* 主内容区域 */}
      <main className="app-main">
        {/* 搜索区域 - 始终可见 */}
        <StockSearch onSearch={handleSearch} loading={loading} />

        {/* 加载状态 */}
        {loading && (
          <div className="loading-container">
            <div className="loading-spinner"></div>
            <h2>正在分析股票数据...</h2>
            <p>基于18步财务分析法，全面评估公司财务状况</p>
            <div className="loading-steps">
              <div className="loading-step active">
                <span className="step-number">1</span>
                <span className="step-text">获取股票基本信息</span>
              </div>
              <div className="loading-step">
                <span className="step-number">2</span>
                <span className="step-text">分析历史财务数据</span>
              </div>
              <div className="loading-step">
                <span className="step-number">3</span>
                <span className="step-text">执行18步财务分析</span>
              </div>
              <div className="loading-step">
                <span className="step-number">4</span>
                <span className="step-text">生成分析报告</span>
              </div>
            </div>
          </div>
        )}

        {/* 错误提示 */}
        {error && (
          <div className="error-container">
            <div className="error-content">
              <h2>分析失败</h2>
              <p>{error}</p>
              <button onClick={() => setError(null)} className="retry-button">
                重新分析
              </button>
            </div>
          </div>
        )}

        {/* 分析结果 */}
        {!loading && !error && report && (
          <div className="result-container">
            {/* 重新搜索按钮 */}
            <div className="back-button-container">
              <button onClick={() => setReport(null)} className="back-button">
                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                搜索其他股票
              </button>
            </div>

            {/* 图表展示 */}
            <Charts historicalData={historicalData} />

            {/* 详细报告 */}
            <AnalysisReport report={report} />
          </div>
        )}
      </main>

      {/* 底部信息 */}
      <footer className="app-footer">
        <div className="footer-content">
          <div className="footer-section">
            <h3>关于系统</h3>
            <p>本系统基于18步财务分析法，自动分析上市公司年报数据，为投资者提供专业、客观的财务分析报告。</p>
          </div>
          <div className="footer-section">
            <h3>分析方法</h3>
            <ul>
              <li>总资产与成长性分析</li>
              <li>资产负债率与偿债能力</li>
              <li>现金流与利润质量</li>
              <li>经营效率与风险评估</li>
            </ul>
          </div>
          <div className="footer-section">
            <h3>免责声明</h3>
            <p>本系统提供的分析报告仅供参考，不构成投资建议。投资者应根据自身风险承受能力谨慎决策。</p>
          </div>
        </div>
        <div className="footer-bottom">
          <p>© 2024 年报分析系统 | 基于18步财务分析法</p>
        </div>
      </footer>

      {/* 全局样式 */}
      <style>{`
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        .app {
          min-height: 100vh;
          display: flex;
          flex-direction: column;
          background: #f8f9ff;
        }

        /* 头部导航 */
        .app-header {
          background: white;
          box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
          position: sticky;
          top: 0;
          z-index: 100;
        }

        .header-content {
          max-width: 1200px;
          margin: 0 auto;
          padding: 15px 20px;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .logo {
          display: flex;
          align-items: center;
          gap: 10px;
          font-size: 1.3rem;
          font-weight: 700;
          color: #667eea;
        }

        .nav-links {
          display: flex;
          gap: 30px;
        }

        .nav-links a {
          color: #666;
          text-decoration: none;
          font-weight: 500;
          transition: color 0.3s;
        }

        .nav-links a:hover {
          color: #667eea;
        }

        /* 主内容区域 */
        .app-main {
          flex: 1;
        }

        /* 加载状态 */
        .loading-container {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 80px 20px;
          text-align: center;
        }

        .loading-spinner {
          width: 60px;
          height: 60px;
          border: 4px solid #e0e0e0;
          border-top-color: #667eea;
          border-radius: 50%;
          animation: spin 1s linear infinite;
          margin-bottom: 30px;
        }

        @keyframes spin {
          to {
            transform: rotate(360deg);
          }
        }

        .loading-container h2 {
          color: #1a1a2e;
          margin-bottom: 10px;
          font-size: 1.5rem;
        }

        .loading-container p {
          color: #666;
          margin-bottom: 40px;
        }

        .loading-steps {
          display: flex;
          gap: 40px;
          flex-wrap: wrap;
          justify-content: center;
        }

        .loading-step {
          display: flex;
          align-items: center;
          gap: 10px;
          opacity: 0.5;
          transition: all 0.3s;
        }

        .loading-step.active {
          opacity: 1;
        }

        .step-number {
          width: 30px;
          height: 30px;
          background: #667eea;
          color: white;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 600;
        }

        .loading-step.active .step-number {
          background: #10b981;
        }

        .step-text {
          color: #666;
          font-size: 0.95rem;
        }

        /* 错误状态 */
        .error-container {
          display: flex;
          justify-content: center;
          align-items: center;
          padding: 80px 20px;
        }

        .error-content {
          background: white;
          padding: 50px;
          border-radius: 20px;
          text-align: center;
          box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
          max-width: 500px;
        }

        .error-content h2 {
          color: #ef4444;
          margin-bottom: 15px;
        }

        .error-content p {
          color: #666;
          margin-bottom: 30px;
        }

        .retry-button {
          padding: 12px 30px;
          background: #667eea;
          color: white;
          border: none;
          border-radius: 10px;
          font-size: 1rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s;
        }

        .retry-button:hover {
          background: #5a6fd6;
          transform: translateY(-2px);
        }

        /* 结果容器 */
        .result-container {
          max-width: 1400px;
          margin: 0 auto;
          padding: 20px;
        }

        .back-button-container {
          margin-bottom: 20px;
        }

        .back-button {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 10px 20px;
          background: white;
          color: #666;
          border: 1px solid #e0e0e0;
          border-radius: 10px;
          font-size: 0.95rem;
          cursor: pointer;
          transition: all 0.3s;
        }

        .back-button:hover {
          background: #f8f9ff;
          color: #667eea;
          border-color: #667eea;
        }

        /* 底部信息 */
        .app-footer {
          background: #1a1a2e;
          color: white;
          padding: 60px 20px 20px;
          margin-top: auto;
        }

        .footer-content {
          max-width: 1200px;
          margin: 0 auto;
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 40px;
          margin-bottom: 40px;
        }

        .footer-section h3 {
          font-size: 1.1rem;
          margin-bottom: 20px;
          color: #667eea;
        }

        .footer-section p {
          color: #999;
          line-height: 1.8;
          font-size: 0.95rem;
        }

        .footer-section ul {
          list-style: none;
        }

        .footer-section li {
          color: #999;
          padding: 8px 0;
          font-size: 0.95rem;
        }

        .footer-section li::before {
          content: '•';
          color: #667eea;
          margin-right: 10px;
        }

        .footer-bottom {
          max-width: 1200px;
          margin: 0 auto;
          padding-top: 20px;
          border-top: 1px solid #333;
          text-align: center;
        }

        .footer-bottom p {
          color: #666;
          font-size: 0.9rem;
        }

        /* 响应式设计 */
        @media (max-width: 768px) {
          .header-content {
            flex-direction: column;
            gap: 15px;
          }

          .nav-links {
            gap: 20px;
          }

          .loading-steps {
            flex-direction: column;
            gap: 20px;
          }

          .footer-content {
            grid-template-columns: 1fr;
          }
        }
      `}</style>
    </div>
  );
};

export default App;
