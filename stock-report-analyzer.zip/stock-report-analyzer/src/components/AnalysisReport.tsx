import React from 'react';
import {
  StockAnalysisReport,
  ANALYSIS_STANDARDS
} from '@/types/stock';

interface AnalysisReportProps {
  report: StockAnalysisReport;
}

const AnalysisReport: React.FC<AnalysisReportProps> = ({ report }) => {
  const { overallAssessment } = report;

  // 获取状态对应的颜色
  const getStatusColor = (status: string): string => {
    switch (status) {
      case 'good':
        return '#10b981';
      case 'warning':
        return '#f59e0b';
      case 'bad':
        return '#ef4444';
      default:
        return '#6b7280';
    }
  };

  // 获取风险等级对应的颜色
  const getRiskColor = (level: string): string => {
    switch (level) {
      case 'low':
        return '#10b981';
      case 'medium':
        return '#f59e0b';
      case 'high':
        return '#ef4444';
      default:
        return '#6b7280';
    }
  };

  // 获取评分对应的颜色
  const getScoreColor = (score: number): string => {
    if (score >= 80) return '#10b981';
    if (score >= 60) return '#f59e0b';
    if (score >= 40) return '#f97316';
    return '#ef4444';
  };

  const renderSection = (
    title: string,
    section: { title: string; content: string; score?: number; status?: string; metrics?: any[] }
  ) => (
    <div className="report-section">
      <div className="section-header">
        <h2>{title}</h2>
        {section.score !== undefined && (
          <div
            className="section-score"
            style={{ backgroundColor: getScoreColor(section.score) }}
          >
            {section.score}分
          </div>
        )}
      </div>

      <div className="section-content">
        <p>{section.content}</p>
      </div>

      {section.metrics && (
        <div className="metrics-grid">
          {section.metrics.map((metric, index) => (
            <div key={index} className="metric-card">
              <div className="metric-name">{metric.name}</div>
              <div
                className="metric-value"
                style={{ color: getStatusColor(metric.status) }}
              >
                {metric.value}
              </div>
              <div className="metric-standard">{metric.standard}</div>
              <div
                className="metric-status"
                style={{ backgroundColor: getStatusColor(metric.status) }}
              >
                {metric.status === 'good' ? '良好' : metric.status === 'warning' ? '一般' : '较差'}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <div className="analysis-report">
      {/* 基本信息 */}
      <div className="report-header">
        <div className="company-info">
          <h1>{report.basicInfo.companyName}</h1>
          <div className="company-details">
            <span className="stock-code">股票代码: {report.basicInfo.stockCode}</span>
            <span className="industry">所属行业: {report.basicInfo.industry}</span>
            <span className="list-date">上市日期: {report.basicInfo.listDate}</span>
          </div>
        </div>

        <div className="overall-score">
          <div
            className="score-circle"
            style={{
              background: `conic-gradient(${getScoreColor(overallAssessment.score)} ${overallAssessment.score * 3.6}deg, #e0e0e0 0deg)`,
            }}
          >
            <div className="score-inner">
              <span className="score-value">{overallAssessment.score}</span>
              <span className="score-label">综合评分</span>
            </div>
          </div>

          <div
            className="risk-badge"
            style={{ backgroundColor: getRiskColor(overallAssessment.riskLevel) }}
          >
            风险等级: {overallAssessment.riskLevel === 'low' ? '低风险' : overallAssessment.riskLevel === 'medium' ? '中等风险' : '高风险'}
          </div>

          <div className="recommendation">{overallAssessment.recommendation}</div>
        </div>
      </div>

      {/* 能力雷达图 */}
      <div className="capability-section">
        <h2>核心能力评估</h2>
        <div className="capability-grid">
          <div className="capability-item">
            <div className="capability-name">财务健康</div>
            <div className="capability-bar">
              <div
                className="capability-fill"
                style={{
                  width: `${overallAssessment.totalAssetsScore}%`,
                  backgroundColor: getScoreColor(overallAssessment.totalAssetsScore)
                }}
              ></div>
            </div>
            <div className="capability-score">{overallAssessment.totalAssetsScore}分</div>
          </div>

          <div className="capability-item">
            <div className="capability-name">偿债能力</div>
            <div className="capability-bar">
              <div
                className="capability-fill"
                style={{
                  width: `${overallAssessment.debtScore}%`,
                  backgroundColor: getScoreColor(overallAssessment.debtScore)
                }}
              ></div>
            </div>
            <div className="capability-score">{overallAssessment.debtScore}分</div>
          </div>

          <div className="capability-item">
            <div className="capability-name">现金流</div>
            <div className="capability-bar">
              <div
                className="capability-fill"
                style={{
                  width: `${overallAssessment.cashScore}%`,
                  backgroundColor: getScoreColor(overallAssessment.cashScore)
                }}
              ></div>
            </div>
            <div className="capability-score">{overallAssessment.cashScore}分</div>
          </div>

          <div className="capability-item">
            <div className="capability-name">成长能力</div>
            <div className="capability-bar">
              <div
                className="capability-fill"
                style={{
                  width: `${overallAssessment.growthScore}%`,
                  backgroundColor: getScoreColor(overallAssessment.growthScore)
                }}
              ></div>
            </div>
            <div className="capability-score">{overallAssessment.growthScore}分</div>
          </div>

          <div className="capability-item">
            <div className="capability-name">经营质量</div>
            <div className="capability-bar">
              <div
                className="capability-fill"
                style={{
                  width: `${overallAssessment.qualityScore}%`,
                  backgroundColor: getScoreColor(overallAssessment.qualityScore)
                }}
              ></div>
            </div>
            <div className="capability-score">{overallAssessment.qualityScore}分</div>
          </div>
        </div>
      </div>

      {/* 详细分析报告 */}
      <div className="sections-container">
        {renderSection('财务健康度', report.financialHealth)}
        {renderSection('债务风险', report.debtAnalysis)}
        {renderSection('现金流', report.cashFlowAnalysis)}
        {renderSection('成长性', report.growthAnalysis)}
        {renderSection('经营质量', report.operationQuality)}
      </div>

      {/* 优势与劣势 */}
      <div className="strengths-weaknesses">
        <div className="sw-section strengths">
          <h2>公司优势</h2>
          <ul>
            {overallAssessment.strengths.length > 0 ? (
              overallAssessment.strengths.map((strength, index) => (
                <li key={index}>{strength}</li>
              ))
            ) : (
              <li>暂未发现明显优势</li>
            )}
          </ul>
        </div>

        <div className="sw-section weaknesses">
          <h2>潜在风险</h2>
          <ul>
            {overallAssessment.weaknesses.length > 0 ? (
              overallAssessment.weaknesses.map((weakness, index) => (
                <li key={index}>{weakness}</li>
              ))
            ) : (
              <li>暂未发现明显风险</li>
            )}
          </ul>
        </div>
      </div>

      {/* 估值分析 */}
      <div className="valuation-section">
        <h2>估值分析</h2>
        <div className="valuation-content">
          <p>基于公司财务状况和行业分析，合理市盈率估计为{report.valuation.reasonablePE}倍。</p>
          <p>当前估值状态：
            <span style={{
              color: report.valuation.valuationStatus === 'undervalued' ? '#10b981' :
                     report.valuation.valuationStatus === 'overvalued' ? '#ef4444' : '#f59e0b',
              fontWeight: 'bold'
            }}>
              {report.valuation.valuationStatus === 'undervalued' ? '被低估' :
               report.valuation.valuationStatus === 'overvalued' ? '被高估' : '合理'}
            </span>
          </p>
        </div>
      </div>

      {/* 免责声明 */}
      <div className="disclaimer">
        <h3>免责声明</h3>
        <p>
          本报告基于公开财务数据自动生成，仅供参考，不构成投资建议。
          投资者应根据自身风险承受能力谨慎决策，据此投资风险自担。
          报告中的分析方法和评价标准仅供参考，不代表对股票未来表现的预测。
        </p>
      </div>

      <style>{`
        .analysis-report {
          max-width: 1200px;
          margin: 0 auto;
          padding: 30px 20px;
          background: #f8f9ff;
        }

        .report-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          background: white;
          padding: 40px;
          border-radius: 20px;
          margin-bottom: 30px;
          box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }

        .company-info h1 {
          font-size: 2rem;
          color: #1a1a2e;
          margin-bottom: 15px;
        }

        .company-details {
          display: flex;
          gap: 30px;
          flex-wrap: wrap;
        }

        .company-details span {
          color: #666;
          font-size: 0.95rem;
        }

        .overall-score {
          text-align: center;
        }

        .score-circle {
          width: 150px;
          height: 150px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 20px;
        }

        .score-inner {
          width: 120px;
          height: 120px;
          background: white;
          border-radius: 50%;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
        }

        .score-value {
          font-size: 2.5rem;
          font-weight: 700;
          color: #1a1a2e;
        }

        .score-label {
          font-size: 0.9rem;
          color: #666;
        }

        .risk-badge {
          color: white;
          padding: 8px 20px;
          border-radius: 20px;
          font-size: 0.95rem;
          margin-bottom: 15px;
          display: inline-block;
        }

        .recommendation {
          font-size: 1.1rem;
          font-weight: 600;
          color: #1a1a2e;
          max-width: 300px;
        }

        .capability-section {
          background: white;
          padding: 40px;
          border-radius: 20px;
          margin-bottom: 30px;
          box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }

        .capability-section h2 {
          color: #1a1a2e;
          margin-bottom: 30px;
          font-size: 1.5rem;
        }

        .capability-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 25px;
        }

        .capability-item {
          display: flex;
          align-items: center;
          gap: 15px;
        }

        .capability-name {
          width: 80px;
          font-size: 0.95rem;
          color: #666;
        }

        .capability-bar {
          flex: 1;
          height: 12px;
          background: #e0e0e0;
          border-radius: 6px;
          overflow: hidden;
        }

        .capability-fill {
          height: 100%;
          border-radius: 6px;
          transition: width 0.5s ease;
        }

        .capability-score {
          width: 50px;
          font-size: 0.9rem;
          font-weight: 600;
          color: #1a1a2e;
        }

        .sections-container {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
          gap: 30px;
          margin-bottom: 30px;
        }

        .report-section {
          background: white;
          padding: 30px;
          border-radius: 20px;
          box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }

        .section-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 20px;
        }

        .section-header h2 {
          color: #1a1a2e;
          font-size: 1.3rem;
        }

        .section-score {
          color: white;
          padding: 8px 15px;
          border-radius: 20px;
          font-weight: 600;
          font-size: 0.95rem;
        }

        .section-content {
          color: #666;
          line-height: 1.8;
          margin-bottom: 25px;
        }

        .metrics-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 15px;
        }

        .metric-card {
          background: #f8f9ff;
          padding: 20px;
          border-radius: 12px;
          text-align: center;
        }

        .metric-name {
          font-size: 0.9rem;
          color: #666;
          margin-bottom: 10px;
        }

        .metric-value {
          font-size: 1.3rem;
          font-weight: 700;
          margin-bottom: 8px;
        }

        .metric-standard {
          font-size: 0.8rem;
          color: #999;
          margin-bottom: 10px;
        }

        .metric-status {
          color: white;
          padding: 4px 12px;
          border-radius: 12px;
          font-size: 0.8rem;
          display: inline-block;
        }

        .strengths-weaknesses {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 30px;
          margin-bottom: 30px;
        }

        .sw-section {
          background: white;
          padding: 30px;
          border-radius: 20px;
          box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }

        .sw-section h2 {
          color: #1a1a2e;
          margin-bottom: 20px;
          font-size: 1.3rem;
        }

        .strengths h2 {
          border-bottom: 3px solid #10b981;
        }

        .weaknesses h2 {
          border-bottom: 3px solid #ef4444;
        }

        .sw-section ul {
          list-style: none;
        }

        .sw-section li {
          padding: 12px 0;
          border-bottom: 1px solid #f0f0f0;
          color: #666;
          line-height: 1.6;
          padding-left: 25px;
          position: relative;
        }

        .strengths li::before {
          content: '✓';
          position: absolute;
          left: 0;
          color: #10b981;
          font-weight: bold;
        }

        .weaknesses li::before {
          content: '⚠';
          position: absolute;
          left: 0;
          color: #ef4444;
        }

        .valuation-section {
          background: white;
          padding: 30px;
          border-radius: 20px;
          margin-bottom: 30px;
          box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }

        .valuation-section h2 {
          color: #1a1a2e;
          margin-bottom: 20px;
          font-size: 1.3rem;
        }

        .valuation-content p {
          color: #666;
          line-height: 1.8;
          margin-bottom: 10px;
        }

        .disclaimer {
          background: #fff3cd;
          padding: 25px;
          border-radius: 12px;
          border: 1px solid #ffc107;
        }

        .disclaimer h3 {
          color: #856404;
          margin-bottom: 15px;
          font-size: 1rem;
        }

        .disclaimer p {
          color: #856404;
          font-size: 0.9rem;
          line-height: 1.6;
        }

        @media (max-width: 768px) {
          .report-header {
            flex-direction: column;
            gap: 30px;
          }

          .company-details {
            flex-direction: column;
            gap: 10px;
          }

          .sections-container,
          .strengths-weaknesses {
            grid-template-columns: 1fr;
          }

          .metrics-grid {
            grid-template-columns: 1fr;
          }
        }
      `}</style>
    </div>
  );
};

export default AnalysisReport;
