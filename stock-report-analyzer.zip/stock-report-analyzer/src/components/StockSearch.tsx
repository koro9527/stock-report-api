import React, { useState } from 'react';
import { Search, LineChart } from 'lucide-react';

interface StockSearchProps {
  onSearch: (symbol: string) => void;
  loading: boolean;
}

const StockSearch: React.FC<StockSearchProps> = ({ onSearch, loading }) => {
  const [symbol, setSymbol] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (symbol.trim()) {
      onSearch(symbol.trim().toUpperCase());
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSubmit(e as React.FormEvent);
    }
  };

  return (
    <div className="stock-search">
      <div className="search-container">
        <h1 className="search-title">
          <LineChart className="title-icon" />
          上市公司年报智能分析系统
        </h1>
        <p className="search-subtitle">
          基于18步财务分析法，自动分析上市公司年报数据，生成专业投资分析报告
        </p>

        <form onSubmit={handleSubmit} className="search-form">
          <div className="input-group">
            <LineChart className="input-icon" size={20} />
            <input
              type="text"
              value={symbol}
              onChange={(e) => setSymbol(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="请输入股票代码（如：000001, 600519）"
              className="search-input"
              disabled={loading}
            />
          </div>

          <button
            type="submit"
            disabled={loading || !symbol.trim()}
            className="search-button"
          >
            {loading ? (
              <>
                <span className="spinner"></span>
                分析中...
              </>
            ) : (
              <>
                <Search size={20} />
                开始分析
              </>
            )}
          </button>
        </form>

        <div className="search-tips">
          <h3>使用说明</h3>
          <ul>
            <li>支持沪市股票代码（如：600519）</li>
            <li>支持深市股票代码（如：000001）</li>
            <li>分析基于最近5年财务数据</li>
            <li>采用18步财务分析法进行全面评估</li>
          </ul>
        </div>
      </div>

      <style>{`
        .stock-search {
          padding: 40px 20px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          min-height: 60vh;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .search-container {
          max-width: 800px;
          width: 100%;
          background: white;
          border-radius: 20px;
          padding: 50px;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        }

        .search-title {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 15px;
          font-size: 2.2rem;
          font-weight: 700;
          color: #1a1a2e;
          margin-bottom: 15px;
        }

        .title-icon {
          color: #667eea;
        }

        .search-subtitle {
          text-align: center;
          color: #666;
          font-size: 1.1rem;
          margin-bottom: 40px;
          line-height: 1.6;
        }

        .search-form {
          display: flex;
          gap: 15px;
          margin-bottom: 30px;
        }

        .input-group {
          flex: 1;
          position: relative;
          display: flex;
          align-items: center;
        }

        .input-icon {
          position: absolute;
          left: 20px;
          color: #667eea;
          z-index: 1;
        }

        .search-input {
          width: 100%;
          padding: 18px 20px 18px 55px;
          border: 2px solid #e0e0e0;
          border-radius: 12px;
          font-size: 1.1rem;
          outline: none;
          transition: all 0.3s;
        }

        .search-input:focus {
          border-color: #667eea;
          box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }

        .search-input:disabled {
          background-color: #f5f5f5;
          cursor: not-allowed;
        }

        .search-button {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 18px 35px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          border: none;
          border-radius: 12px;
          font-size: 1.1rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s;
        }

        .search-button:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }

        .search-button:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }

        .spinner {
          width: 20px;
          height: 20px;
          border: 2px solid transparent;
          border-top-color: white;
          border-radius: 50%;
          animation: spin 1s linear infinite;
        }

        @keyframes spin {
          to {
            transform: rotate(360deg);
          }
        }

        .search-tips {
          background: #f8f9ff;
          border-radius: 12px;
          padding: 25px;
        }

        .search-tips h3 {
          color: #1a1a2e;
          margin-bottom: 15px;
          font-size: 1.1rem;
        }

        .search-tips ul {
          list-style: none;
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 10px;
        }

        .search-tips li {
          color: #666;
          font-size: 0.95rem;
          padding-left: 25px;
          position: relative;
        }

        .search-tips li::before {
          content: '✓';
          position: absolute;
          left: 0;
          color: #667eea;
          font-weight: bold;
        }

        @media (max-width: 768px) {
          .search-container {
            padding: 30px 20px;
          }

          .search-title {
            font-size: 1.6rem;
          }

          .search-form {
            flex-direction: column;
          }

          .search-tips ul {
            grid-template-columns: 1fr;
          }
        }
      `}</style>
    </div>
  );
};

export default StockSearch;
