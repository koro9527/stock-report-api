import React from 'react';
import { FinancialData } from '@/types/stock';

interface ChartsProps {
  historicalData: FinancialData[];
}

const Charts: React.FC<ChartsProps> = ({ historicalData }) => {
  // 准备图表数据 - 按年份升序排列
  const sortedData = [...historicalData].sort((a, b) => a.year - b.year);

  const chartData = sortedData.map((data) => ({
    year: data.year.toString(),
    totalAssets: Math.round(data.totalAssets / 100000000), // 转换为亿元
    revenue: Math.round(data.revenue / 100000000), // 转换为亿元
    netProfit: Math.round(data.netProfit / 10000000), // 转换为亿元（缩小10倍便于显示）
    roe: parseFloat(data.roe.toFixed(2)),
    currencyFunds: Math.round(data.currencyFunds / 100000000), // 转换为亿元
    revenueGrowth: 0, // 将在下面计算
    netProfitGrowth: 0 // 将在下面计算
  }));

  // 计算增长率
  for (let i = 1; i < chartData.length; i++) {
    chartData[i].revenueGrowth = parseFloat(
      ((chartData[i].revenue - chartData[i-1].revenue) / chartData[i-1].revenue * 100).toFixed(1)
    );
    chartData[i].netProfitGrowth = parseFloat(
      ((chartData[i].netProfit - chartData[i-1].netProfit) / chartData[i-1].netProfit * 100).toFixed(1)
    );
  }

  // 计算各指标的最大值用于缩放
  const maxAssets = Math.max(...chartData.map(d => d.totalAssets)) * 1.2;
  const maxRevenue = Math.max(...chartData.map(d => d.revenue)) * 1.2;
  const maxNetProfit = Math.max(...chartData.map(d => d.netProfit)) * 1.2;
  const maxROE = Math.max(...chartData.map(d => d.roe), 30); // 最小30%确保ROE显示合理
  const maxCash = Math.max(...chartData.map(d => d.currencyFunds)) * 1.2;

  // 生成柱状图路径
  const generateBarPath = (data: typeof chartData, key: keyof typeof chartData[number], maxValue: number, barWidth: number): string => {
    const points: string[] = [];
    data.forEach((d, index) => {
      const x = (index / data.length) * 100;
      const y = 100 - ((d[key] as number) / maxValue) * 100;
      // 柱状图：矩形四个点
      points.push(`${x}%,${y}%`);
      points.push(`${x + barWidth}%,${y}%`);
      points.push(`${x + barWidth}%,100%`);
      points.push(`${x}%,100%`);
    });
    return points.join(' ');
  };

  // 生成折线路径
  const generateLinePath = (data: typeof chartData, key: keyof typeof chartData[number], maxValue: number): string => {
    const points = data.map((d, index) => {
      const x = (index / (data.length - 1)) * 100;
      const y = 100 - ((d[key] as number) / maxValue) * 100;
      return `${x}%,${y}%`;
    });
    return points.join(' ');
  };

  // 计算柱状图每个柱的宽度和位置
  const getBarPosition = (index: number, total: number) => {
    const barWidth = (90 / total); // 使用90%的宽度留出间隙
    const gap = barWidth * 0.2; // 柱之间的间隙
    const startX = 5 + (index * barWidth) + (gap / 2); // 从5%开始
    return { startX, width: barWidth - gap };
  };

  // 绘制总资产柱状图
  const renderAssetsChart = () => {
    return (
      <div className="chart-container">
        <h3>总资产趋势（亿元）</h3>
        <div className="chart-wrapper">
          <div className="y-axis-labels">
            <span>{maxAssets.toFixed(0)}亿</span>
            <span>{(maxAssets * 0.75).toFixed(0)}亿</span>
            <span>{(maxAssets * 0.5).toFixed(0)}亿</span>
            <span>{(maxAssets * 0.25).toFixed(0)}亿</span>
            <span>0</span>
          </div>
          <div className="chart-content">
            <svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet" className="chart-svg">
              {/* 背景网格线 */}
              {[0.25, 0.5, 0.75, 1].map((ratio) => (
                <line
                  key={ratio}
                  x1="0"
                  y1={ratio * 100}
                  x2="100"
                  y2={ratio * 100}
                  stroke="#e8e8e8"
                  strokeWidth="0.3"
                />
              ))}
              {/* 柱状图 */}
              {chartData.map((d, index) => {
                const { startX, width } = getBarPosition(index, chartData.length);
                const y = 100 - (d.totalAssets / maxAssets) * 100;
                return (
                  <g key={index}>
                    <rect
                      x={`${startX}%`}
                      y={`${y}%`}
                      width={`${width}%`}
                      height={`${100 - y}%`}
                      fill="#667eea"
                      rx="1"
                      ry="1"
                    />
                  </g>
                );
              })}
            </svg>
            {/* 数据标签 */}
            <div className="bar-labels">
              {chartData.map((d, index) => {
                const { startX, width } = getBarPosition(index, chartData.length);
                return (
                  <div
                    key={index}
                    className="bar-label"
                    style={{ left: `${startX}%`, width: `${width}%` }}
                  >
                    <span className="bar-value">{d.totalAssets.toFixed(0)}亿</span>
                    <span className="bar-year">{d.year}年</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    );
  };

  // 绘制营收利润柱状折线组合图
  const renderRevenueChart = () => {
    return (
      <div className="chart-container">
        <h3>营业收入与净利润趋势（亿元）</h3>
        <div className="chart-wrapper">
          <div className="y-axis-labels">
            <span>{maxRevenue.toFixed(0)}亿</span>
            <span>{(maxRevenue * 0.75).toFixed(0)}亿</span>
            <span>{(maxRevenue * 0.5).toFixed(0)}亿</span>
            <span>{(maxRevenue * 0.25).toFixed(0)}亿</span>
            <span>0</span>
          </div>
          <div className="chart-content">
            <svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet" className="chart-svg">
              {/* 背景网格线 */}
              {[0.25, 0.5, 0.75, 1].map((ratio) => (
                <line
                  key={ratio}
                  x1="0"
                  y1={ratio * 100}
                  x2="100"
                  y2={ratio * 100}
                  stroke="#e8e8e8"
                  strokeWidth="0.3"
                />
              ))}
              {/* 营业收入柱状图 */}
              {chartData.map((d, index) => {
                const { startX, width } = getBarPosition(index, chartData.length);
                const y = 100 - (d.revenue / maxRevenue) * 100;
                return (
                  <rect
                    key={`revenue-${index}`}
                    x={`${startX}%`}
                    y={`${y}%`}
                    width={`${width * 0.45}%`}
                    height={`${100 - y}%`}
                    fill="#667eea"
                    rx="1"
                    ry="1"
                  />
                );
              })}
              {/* 净利润柱状图 */}
              {chartData.map((d, index) => {
                const { startX, width } = getBarPosition(index, chartData.length);
                const y = 100 - (d.netProfit / maxNetProfit) * 100;
                return (
                  <rect
                    key={`profit-${index}`}
                    x={`${startX + width * 0.45}%`}
                    y={`${y}%`}
                    width={`${width * 0.45}%`}
                    height={`${100 - y}%`}
                    fill="#10b981"
                    rx="1"
                    ry="1"
                  />
                );
              })}
              {/* 净利润趋势折线 */}
              <polyline
                points={generateLinePath(chartData, 'netProfit', maxNetProfit)}
                fill="none"
                stroke="#f59e0b"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              {/* 趋势线数据点 */}
              {chartData.map((d, index) => {
                const x = (index / (chartData.length - 1)) * 100;
                const y = 100 - (d.netProfit / maxNetProfit) * 100;
                return (
                  <circle
                    key={`line-${index}`}
                    cx={`${x}%`}
                    cy={`${y}%`}
                    r="2"
                    fill="#f59e0b"
                    stroke="white"
                    strokeWidth="0.5"
                  />
                );
              })}
            </svg>
            {/* 数据标签 */}
            <div className="bar-labels">
              {chartData.map((d, index) => {
                const { startX, width } = getBarPosition(index, chartData.length);
                return (
                  <div
                    key={index}
                    className="bar-label double"
                    style={{ left: `${startX}%`, width: `${width}%` }}
                  >
                    <div className="bar-values">
                      <span className="revenue">{d.revenue.toFixed(0)}亿</span>
                      <span className="profit">{d.netProfit.toFixed(0)}亿</span>
                    </div>
                    <span className="bar-year">{d.year}年</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
        <div className="chart-legend">
          <span className="legend-item">
            <span className="legend-bar revenue"></span>
            营业收入
          </span>
          <span className="legend-item">
            <span className="legend-bar profit"></span>
            净利润
          </span>
          <span className="legend-item">
            <span className="legend-line"></span>
            净利润趋势线
          </span>
        </div>
      </div>
    );
  };

  // 绘制ROE柱状折线组合图
  const renderROEChart = () => {
    return (
      <div className="chart-container">
        <h3>净资产收益率（ROE）趋势</h3>
        <div className="chart-wrapper">
          <div className="y-axis-labels">
            <span>{maxROE.toFixed(0)}%</span>
            <span>{(maxROE * 0.75).toFixed(0)}%</span>
            <span>{(maxROE * 0.5).toFixed(0)}%</span>
            <span>{(maxROE * 0.25).toFixed(0)}%</span>
            <span>0%</span>
          </div>
          <div className="chart-content">
            <svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet" className="chart-svg">
              {/* 参考线 */}
              <line x1="0" y1={100 - (15 / maxROE) * 100} x2="100" y2={100 - (15 / maxROE) * 100} stroke="#10b981" strokeWidth="0.5" strokeDasharray="2,1" />
              <line x1="0" y1={100 - (10 / maxROE) * 100} x2="100" y2={100 - (10 / maxROE) * 100} stroke="#f59e0b" strokeWidth="0.5" strokeDasharray="2,1" />
              {/* 背景网格线 */}
              {[0.25, 0.5, 0.75, 1].map((ratio) => (
                <line
                  key={ratio}
                  x1="0"
                  y1={ratio * 100}
                  x2="100"
                  y2={ratio * 100}
                  stroke="#e8e8e8"
                  strokeWidth="0.3"
                />
              ))}
              {/* ROE柱状图 */}
              {chartData.map((d, index) => {
                const { startX, width } = getBarPosition(index, chartData.length);
                const y = 100 - (d.roe / maxROE) * 100;
                const barHeight = (d.roe / maxROE) * 100;
                const fillColor = d.roe >= 15 ? '#10b981' : d.roe >= 10 ? '#f59e0b' : '#ef4444';
                return (
                  <g key={index}>
                    <rect
                      x={`${startX}%`}
                      y={`${y}%`}
                      width={`${width}%`}
                      height={`${barHeight}%`}
                      fill={fillColor}
                      rx="1"
                      ry="1"
                    />
                  </g>
                );
              })}
              {/* ROE趋势折线 */}
              <polyline
                points={generateLinePath(chartData, 'roe', maxROE)}
                fill="none"
                stroke="#8b5cf6"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              {/* 趋势线数据点 */}
              {chartData.map((d, index) => {
                const x = (index / (chartData.length - 1)) * 100;
                const y = 100 - (d.roe / maxROE) * 100;
                return (
                  <circle
                    key={`line-${index}`}
                    cx={`${x}%`}
                    cy={`${y}%`}
                    r="2"
                    fill="#8b5cf6"
                    stroke="white"
                    strokeWidth="0.5"
                  />
                );
              })}
            </svg>
            {/* 数据标签 */}
            <div className="bar-labels">
              {chartData.map((d, index) => {
                const { startX, width } = getBarPosition(index, chartData.length);
                return (
                  <div
                    key={index}
                    className="bar-label"
                    style={{ left: `${startX}%`, width: `${width}%` }}
                  >
                    <span className="bar-value">{d.roe.toFixed(1)}%</span>
                    <span className="bar-year">{d.year}年</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
        <div className="roe-reference">
          <span className="reference-line">
            <span className="dot green"></span>
            优秀线: 15%
          </span>
          <span className="reference-line">
            <span className="dot orange"></span>
            良好线: 10%
          </span>
          <span className="reference-line">
            <span className="line-icon"></span>
            紫色趋势线
          </span>
        </div>
      </div>
    );
  };

  // 绘制货币资金柱状图
  const renderCashChart = () => {
    return (
      <div className="chart-container">
        <h3>货币资金趋势（亿元）</h3>
        <div className="chart-wrapper">
          <div className="y-axis-labels">
            <span>{maxCash.toFixed(0)}亿</span>
            <span>{(maxCash * 0.75).toFixed(0)}亿</span>
            <span>{(maxCash * 0.5).toFixed(0)}亿</span>
            <span>{(maxCash * 0.25).toFixed(0)}亿</span>
            <span>0</span>
          </div>
          <div className="chart-content">
            <svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet" className="chart-svg">
              {/* 背景网格线 */}
              {[0.25, 0.5, 0.75, 1].map((ratio) => (
                <line
                  key={ratio}
                  x1="0"
                  y1={ratio * 100}
                  x2="100"
                  y2={ratio * 100}
                  stroke="#e8e8e8"
                  strokeWidth="0.3"
                />
              ))}
              {/* 柱状图 */}
              {chartData.map((d, index) => {
                const { startX, width } = getBarPosition(index, chartData.length);
                const y = 100 - (d.currencyFunds / maxCash) * 100;
                return (
                  <g key={index}>
                    <rect
                      x={`${startX}%`}
                      y={`${y}%`}
                      width={`${width}%`}
                      height={`${100 - y}%`}
                      fill="#3b82f6"
                      rx="1"
                      ry="1"
                    />
                  </g>
                );
              })}
              {/* 现金流趋势折线 */}
              <polyline
                points={generateLinePath(chartData, 'currencyFunds', maxCash)}
                fill="none"
                stroke="#06b6d4"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeDasharray="3,2"
              />
              {/* 趋势线数据点 */}
              {chartData.map((d, index) => {
                const x = (index / (chartData.length - 1)) * 100;
                const y = 100 - (d.currencyFunds / maxCash) * 100;
                return (
                  <circle
                    key={`line-${index}`}
                    cx={`${x}%`}
                    cy={`${y}%`}
                    r="2"
                    fill="#06b6d4"
                    stroke="white"
                    strokeWidth="0.5"
                  />
                );
              })}
            </svg>
            {/* 数据标签 */}
            <div className="bar-labels">
              {chartData.map((d, index) => {
                const { startX, width } = getBarPosition(index, chartData.length);
                return (
                  <div
                    key={index}
                    className="bar-label"
                    style={{ left: `${startX}%`, width: `${width}%` }}
                  >
                    <span className="bar-value">{d.currencyFunds.toFixed(0)}亿</span>
                    <span className="bar-year">{d.year}年</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
        <div className="chart-legend">
          <span className="legend-item">
            <span className="legend-bar cash"></span>
            货币资金
          </span>
          <span className="legend-item">
            <span className="legend-line dashed"></span>
            现金流趋势
          </span>
        </div>
      </div>
    );
  };

  return (
    <div className="charts-section">
      <h2>财务数据可视化分析</h2>

      <div className="charts-grid">
        {renderAssetsChart()}
        {renderRevenueChart()}
        {renderROEChart()}
        {renderCashChart()}
      </div>

      <style>{`
        .charts-section {
          background: white;
          padding: 24px;
          border-radius: 16px;
          margin: 20px 0;
          box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
        }

        .charts-section h2 {
          color: #1a1a2e;
          margin-bottom: 24px;
          font-size: 1.25rem;
          font-weight: 600;
        }

        .charts-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
          gap: 24px;
        }

        .chart-container {
          background: linear-gradient(135deg, #f8f9ff 0%, #ffffff 100%);
          padding: 20px;
          border-radius: 12px;
          border: 1px solid #e8e8ff;
        }

        .chart-container h3 {
          color: #1a1a2e;
          margin-bottom: 16px;
          font-size: 1rem;
          font-weight: 600;
        }

        .chart-wrapper {
          display: flex;
          flex-direction: row;
          height: 260px;
        }

        .y-axis-labels {
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          width: 56px;
          padding-right: 12px;
          border-right: 2px solid #e8e8e8;
          flex-shrink: 0;
        }

        .y-axis-labels span {
          font-size: 0.7rem;
          color: #888;
          text-align: right;
          line-height: 1;
        }

        .chart-content {
          flex: 1;
          position: relative;
          padding: 0 8px;
          min-width: 0;
        }

        .chart-svg {
          width: 100%;
          height: 180px;
          overflow: visible;
        }

        .bar-labels {
          position: absolute;
          bottom: -40px;
          left: 8px;
          right: 8px;
          display: flex;
          justify-content: space-around;
          height: 40px;
        }

        .bar-label {
          position: absolute;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: flex-end;
          height: 100%;
          transform: translateX(-50%);
        }

        .bar-label.double {
          flex-direction: column;
        }

        .bar-value {
          font-size: 0.7rem;
          font-weight: 600;
          color: #1a1a2e;
          margin-bottom: 2px;
          white-space: nowrap;
        }

        .bar-year {
          font-size: 0.65rem;
          color: #888;
        }

        .bar-values {
          display: flex;
          flex-direction: column;
          align-items: center;
          margin-bottom: 2px;
        }

        .bar-values .revenue {
          color: #667eea;
          font-size: 0.7rem;
          font-weight: 600;
        }

        .bar-values .profit {
          color: #10b981;
          font-size: 0.7rem;
          font-weight: 600;
        }

        .chart-legend {
          display: flex;
          justify-content: center;
          gap: 24px;
          margin-top: 16px;
          padding-top: 12px;
          border-top: 1px solid #e8e8e8;
          flex-wrap: wrap;
        }

        .legend-item {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 0.8rem;
          color: #666;
        }

        .legend-bar {
          width: 14px;
          height: 14px;
          border-radius: 3px;
        }

        .legend-bar.revenue {
          background: #667eea;
        }

        .legend-bar.profit {
          background: #10b981;
        }

        .legend-bar.cash {
          background: #3b82f6;
        }

        .legend-line {
          width: 20px;
          height: 3px;
          background: #f59e0b;
          border-radius: 2px;
        }

        .legend-line.dashed {
          background: repeating-linear-gradient(
            90deg,
            #06b6d4,
            #06b6d4 4px,
            transparent 4px,
            transparent 6px
          );
          height: 2px;
        }

        .roe-reference {
          display: flex;
          justify-content: space-between;
          margin-top: 16px;
          padding-top: 12px;
          border-top: 1px solid #e8e8e8;
          flex-wrap: wrap;
          gap: 8px;
        }

        .reference-line {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 0.75rem;
          color: #666;
        }

        .reference-line .dot {
          width: 10px;
          height: 10px;
          border-radius: 50%;
        }

        .reference-line .dot.green {
          background: #10b981;
        }

        .reference-line .dot.orange {
          background: #f59e0b;
        }

        .reference-line .line-icon {
          width: 16px;
          height: 2px;
          background: #8b5cf6;
          border-radius: 1px;
        }

        @media (max-width: 640px) {
          .charts-grid {
            grid-template-columns: 1fr;
          }

          .chart-wrapper {
            flex-direction: column;
            height: auto;
          }

          .y-axis-labels {
            flex-direction: row;
            width: 100%;
            padding-right: 0;
            padding-bottom: 8px;
            margin-bottom: 8px;
            border-right: none;
            border-bottom: 1px solid #e8e8e8;
          }

          .y-axis-labels span {
            font-size: 0.65rem;
          }

          .chart-content {
            padding: 0;
          }

          .chart-svg {
            height: 160px;
          }

          .bar-labels {
            position: relative;
            bottom: auto;
            left: auto;
            right: auto;
            margin-top: 8px;
            height: 50px;
            flex-wrap: wrap;
            justify-content: space-between;
          }

          .bar-label {
            position: relative;
            transform: none;
            width: 18% !important;
            left: auto !important;
          }

          .bar-value {
            font-size: 0.65rem;
          }

          .bar-year {
            font-size: 0.6rem;
          }

          .chart-legend {
            gap: 12px;
          }

          .roe-reference {
            justify-content: center;
          }
        }
      `}</style>
    </div>
  );
};

export default Charts;
