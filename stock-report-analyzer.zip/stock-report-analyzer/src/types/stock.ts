// 股票数据类型定义

export interface StockInfo {
  symbol: string;           // 股票代码
  name: string;            // 公司名称
  industry: string;         // 所属行业
  area: string;            // 所在地区
  listDate: string;        // 上市日期
  market: string;          // 上市板块
  totalAssets: number;     // 总资产
  totalAssetsGrowth: number; // 总资产增长率
  totalLiabilities: number; // 负债合计
  debtAssetRatio: number;  // 资产负债率
  currencyFunds: number;  // 货币资金
  tradingAssets: number;   // 交易性金融资产
  interestLiabilities: number; // 有息负债
  netAssets: number;       // 净资产
  revenue: number;         // 营业收入
  revenueGrowth: number;   // 营业收入增长率
  netProfit: number;       // 净利润
  netProfitGrowth: number; // 净利润增长率
  roe: number;             // 净资产收益率
  cashFromOps: number;     // 经营活动现金流
  cashToNetProfitRatio: number; // 净利润现金含量
  receivables: number;     // 应收账款
  contractAssets: number;  // 合同资产
  inventory: number;       // 存货
  goodwill: number;        // 商誉
  fixedAssets: number;     // 固定资产
  constructionInProgress: number; // 在建工程
  investmentAssets: number; // 投资类资产
  advanceReceivables: number; // 预收账款
  payableAccounts: number; // 应付账款
  historicalData?: YearlyFinancialData[]; // 历史财务数据（来自后端API）
}

export interface FinancialData {
  year: number;
  totalAssets: number;
  totalLiabilities: number;
  currencyFunds: number;
  tradingAssets: number;
  receivables: number;
  contractAssets: number;      // 合同资产
  inventory: number;
  goodwill: number;            // 商誉
  fixedAssets: number;
  constructionInProgress: number; // 在建工程
  investmentAssets: number;
  advanceReceivables: number;
  payableAccounts: number;
  revenue: number;
  netProfit: number;
  cashFromOps: number;
  roe: number;
  totalEquity: number;
}

export interface AnalysisResult {
  score: number;              // 综合评分
  totalAssetsScore: number;   // 总资产评分
  debtScore: number;          // 偿债能力评分
  cashScore: number;          // 现金流评分
  growthScore: number;        // 成长能力评分
  qualityScore: number;       // 经营质量评分
  recommendation: string;     // 投资建议
  riskLevel: 'low' | 'medium' | 'high'; // 风险等级
  strengths: string[];        // 优势
  weaknesses: string[];       // 劣势
}

export interface ReportSection {
  title: string;
  content: string;
  score?: number;
  status?: 'good' | 'warning' | 'bad';
  metrics?: {
    name: string;
    value: string | number;
    standard: string;
    status: 'good' | 'warning' | 'bad';
  }[];
}

export interface StockAnalysisReport {
  basicInfo: {
    companyName: string;
    stockCode: string;
    industry: string;
    listDate: string;
    reportDate: string;
  };
  financialHealth: ReportSection;      // 财务健康度
  debtAnalysis: ReportSection;         // 债务分析
  cashFlowAnalysis: ReportSection;     // 现金流分析
  growthAnalysis: ReportSection;       // 成长性分析
  operationQuality: ReportSection;     // 经营质量
  valuation: {
    peRatio: number;
    pbRatio: number;
    marketCap: number;
    reasonablePE: number;
    valuationStatus: 'undervalued' | 'fair' | 'overvalued';
  };
  overallAssessment: AnalysisResult;
}

export const ANALYSIS_STANDARDS = {
  totalAssetsGrowth: {
    good: 10,
    warning: 0,
    unit: '%'
  },
  debtAssetRatio: {
    good: 40,
    warning: 60,
    highRisk: 70,
    unit: '%'
  },
  receivablesRatio: {
    good: 10,
    warning: 20,
    unit: '%'
  },
  inventoryRatio: {
    good: 15,
    warning: 30,
    unit: '%'
  },
  fixedAssetsRatio: {
    good: 40,
    warning: 60,
    unit: '%'
  },
  investmentAssetsRatio: {
    good: 10,
    warning: 20,
    unit: '%'
  },
  goodwillRatio: {
    good: 10,
    warning: 20,
    unit: '%'
  },
  revenueGrowth: {
    good: 10,
    warning: 0,
    unit: '%'
  },
  roe: {
    good: 15,
    warning: 10,
    unit: '%'
  },
  cashToNetProfitRatio: {
    good: 80,
    warning: 50,
    unit: '%'
  }
};

// 年度财务数据（来自后端API）
export interface YearlyFinancialData {
  year: number;
  metrics: FinancialMetrics;
  reportType: string;
}

// 财务指标
export interface FinancialMetrics {
  // 资产类
  totalAssets: number;
  totalLiabilities: number;
  currencyFunds: number;
  tradingAssets: number;
  receivables: number;
  contractAssets: number;
  inventory: number;
  goodwill: number;
  fixedAssets: number;
  constructionInProgress: number;
  investmentAssets: number;
  advanceReceivables: number;

  // 负债类
  payableAccounts: number;
  interestLiabilities: number;

  // 损益类
  revenue: number;
  netProfit: number;

  // 现金流类
  cashFromOps: number;
  cashFromInvesting: number;
  cashFromFinancing: number;

  // 盈利能力指标
  roe: number;
  netProfitMargin: number;
  grossProfitMargin: number;

  // 成长能力指标
  revenueGrowth: number;
  netProfitGrowth: number;
  totalAssetsGrowth: number;

  // 偿债能力指标
  currentRatio: number;
  quickRatio: number;
  debtAssetRatio: number;

  // 营运能力指标
  assetTurnover: number;
  inventoryTurnover: number;
  receivableTurnover: number;

  // 每股指标
  totalEquity: number;
  basicEPS: number;
  dilutedEPS: number;
}
