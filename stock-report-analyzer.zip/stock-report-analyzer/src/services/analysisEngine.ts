// 18步财务分析引擎
import {
  StockInfo,
  FinancialData,
  AnalysisResult,
  ReportSection,
  StockAnalysisReport,
  ANALYSIS_STANDARDS
} from '@/types/stock';

interface StepResult {
  step: number;
  name: string;
  metric: string;
  value: number;
  standard: string;
  status: 'good' | 'warning' | 'bad';
  score: number;
  analysis: string;
}

export class AnalysisEngine {
  private stepResults: StepResult[] = [];

  // 第1-2步：准备数据
  prepareData(data: StockInfo): void {
    // 数据预处理已经在API层完成
    console.log('数据准备完成');
  }

  // 第3步：总资产分析
  analyzeTotalAssets(currentData: FinancialData, historicalData: FinancialData[]): StepResult {
    const latest = currentData;
    const previous = historicalData[historicalData.length - 2];

    const totalAssets = latest.totalAssets;
    const growthRate = previous
      ? ((latest.totalAssets - previous.totalAssets) / previous.totalAssets) * 100
      : 0;

    let status: 'good' | 'warning' | 'bad' = 'warning';
    let score = 50;

    if (growthRate >= ANALYSIS_STANDARDS.totalAssetsGrowth.good) {
      status = 'good';
      score = 100;
    } else if (growthRate < 0) {
      status = 'bad';
      score = 20;
    }

    return {
      step: 3,
      name: '总资产分析',
      metric: '总资产增长率',
      value: growthRate,
      standard: `大于${ANALYSIS_STANDARDS.totalAssetsGrowth.good}%为良好，小于0为收缩`,
      status,
      score,
      analysis: this.generateAssetsAnalysis(growthRate, totalAssets)
    };
  }

  private generateAssetsAnalysis(growthRate: number, totalAssets: number): string {
    let analysis = '';

    if (growthRate >= 10) {
      analysis = `公司总资产规模较大，达到${(totalAssets / 100000000).toFixed(2)}亿元，且处于持续扩张阶段，成长性较好。`;
    } else if (growthRate >= 0) {
      analysis = `公司总资产规模为${(totalAssets / 100000000).toFixed(2)}亿元，增长趋于稳定，公司处于成熟期。`;
    } else {
      analysis = `公司总资产出现负增长，可能处于收缩或衰退阶段，需要进一步分析原因。`;
    }

    return analysis;
  }

  // 第4步：资产负债率分析
  analyzeDebtRatio(currentData: FinancialData): StepResult {
    const debtRatio = (currentData.totalLiabilities / currentData.totalAssets) * 100;

    let status: 'good' | 'warning' | 'bad' = 'good';
    let score = 80;

    if (debtRatio >= 70) {
      status = 'bad';
      score = 20;
    } else if (debtRatio >= 60) {
      status = 'warning';
      score = 50;
    } else if (debtRatio < 40) {
      score = 100;
    }

    return {
      step: 4,
      name: '资产负债率分析',
      metric: '资产负债率',
      value: debtRatio,
      standard: `小于40%无风险，40-60%风险较小，大于70%风险较大`,
      status,
      score,
      analysis: this.generateDebtAnalysis(debtRatio)
    };
  }

  private generateDebtAnalysis(debtRatio: number): string {
    let analysis = '';

    if (debtRatio < 40) {
      analysis = `公司资产负债率为${debtRatio.toFixed(2)}%，处于安全水平，基本没有偿债风险。`;
    } else if (debtRatio < 60) {
      analysis = `公司资产负债率为${debtRatio.toFixed(2)}%，处于合理区间，偿债风险较小。`;
    } else if (debtRatio < 70) {
      analysis = `公司资产负债率为${debtRatio.toFixed(2)}%，需要注意债务风险，在特殊情况下可能发生偿债危机。`;
    } else {
      analysis = `公司资产负债率为${debtRatio.toFixed(2)}%，处于较高水平，发生债务危机的可能性较大。`;
    }

    return analysis;
  }

  // 第5步：准货币资金与有息负债分析
  analyzeCashAndDebt(currentData: FinancialData): StepResult {
    const quasiCash = currentData.currencyFunds + currentData.tradingAssets;
    const interestDebt = currentData.totalLiabilities * 0.6; // 假设有息负债占60%
    const difference = quasiCash - interestDebt;

    const ratio = (quasiCash / interestDebt) * 100;

    let status: 'good' | 'warning' | 'bad' = 'good';
    let score = 80;

    if (quasiCash < interestDebt * 0.5) {
      status = 'bad';
      score = 20;
    } else if (quasiCash < interestDebt) {
      status = 'warning';
      score = 50;
    }

    return {
      step: 5,
      name: '准货币资金分析',
      metric: '准货币资金与有息负债之差',
      value: difference,
      standard: '准货币资金大于有息负债，无偿债压力',
      status,
      score,
      analysis: this.generateCashDebtAnalysis(difference, ratio)
    };
  }

  private generateCashDebtAnalysis(difference: number, ratio: number): string {
    const diffStr = (difference / 100000000).toFixed(2);
    const ratioStr = ratio.toFixed(2);

    if (difference > 0) {
      return `公司准货币资金为有息负债的${ratioStr}%，差额为${diffStr}亿元，现金储备充足，偿债能力较强。`;
    } else {
      return `公司准货币资金为有息负债的${ratioStr}%，存在${Math.abs(parseFloat(diffStr))}亿元的缺口，需要关注债务偿还压力。`;
    }
  }

  // 第6步：两头吃能力分析
  analyzeBusinessPower(currentData: FinancialData): StepResult {
    const advanceReceivables = currentData.advanceReceivables;
    const payableAccounts = currentData.payableAccounts;
    const receivables = currentData.receivables;

    // 应付预收 - 应收预付
    const businessPower = (advanceReceivables + payableAccounts) - receivables;
    const businessPowerRatio = (businessPower / currentData.totalAssets) * 100;

    let status: 'good' | 'warning' | 'bad' = 'good';
    let score = 70;

    if (businessPower < 0) {
      status = 'bad';
      score = 30;
    } else if (businessPowerRatio < 5) {
      status = 'warning';
      score = 50;
    }

    return {
      step: 6,
      name: '两头吃能力分析',
      metric: '应付预收-应收预付差额',
      value: businessPower,
      standard: '差额越大，说明企业对上下游的议价能力越强',
      status,
      score,
      analysis: this.generateBusinessPowerAnalysis(businessPower, businessPowerRatio)
    };
  }

  private generateBusinessPowerAnalysis(power: number, ratio: number): string {
    const powerStr = (power / 100000000).toFixed(2);

    if (power > 0) {
      return `公司应付预收减去应收预付的差额为${powerStr}亿元，占总资产的${ratio.toFixed(2)}%，说明公司对上下游有较强的议价能力，能够占用较多上下游资金。`;
    } else {
      return `公司应付预收减去应收预付的差额为${powerStr}亿元，公司被上下游占用资金，两头吃的能力较弱。`;
    }
  }

  // 第7步：应收账款分析
  analyzeReceivables(currentData: FinancialData): StepResult {
    const receivablesRatio = ((currentData.receivables + currentData.contractAssets) / currentData.totalAssets) * 100;

    let status: 'good' | 'warning' | 'bad' = 'good';
    let score = 80;

    if (receivablesRatio >= ANALYSIS_STANDARDS.receivablesRatio.warning) {
      status = 'warning';
      score = 50;
    }
    if (receivablesRatio >= ANALYSIS_STANDARDS.receivablesRatio.warning * 2) {
      status = 'bad';
      score = 20;
    }

    return {
      step: 7,
      name: '应收账款分析',
      metric: '应收账款+合同资产占比',
      value: receivablesRatio,
      standard: `小于${ANALYSIS_STANDARDS.receivablesRatio.good}%为良好`,
      status,
      score,
      analysis: this.generateReceivablesAnalysis(receivablesRatio)
    };
  }

  private generateReceivablesAnalysis(ratio: number): string {
    if (ratio <= 10) {
      return `公司应收账款和合同资产占总资产的${ratio.toFixed(2)}%，占比合理，说明公司的应收账款管理较好，回款能力较强。`;
    } else if (ratio <= 20) {
      return `公司应收账款和合同资产占总资产的${ratio.toFixed(2)}%，占比偏高，需要关注应收账款周转情况。`;
    } else {
      return `公司应收账款和合同资产占总资产的${ratio.toFixed(2)}%，占比过高，存在较大的坏账风险，需要重点关注。`;
    }
  }

  // 第8步：公司轻重类型分析
  analyzeAssetType(currentData: FinancialData): StepResult {
    const fixedRatio = ((currentData.fixedAssets + currentData.constructionInProgress) / currentData.totalAssets) * 100;

    let status: 'good' | 'warning' | 'bad' = 'good';
    let score = 70;
    let analysis = '';

    if (fixedRatio < ANALYSIS_STANDARDS.fixedAssetsRatio.good) {
      status = 'good';
      score = 100;
      analysis = `公司固定资产和在建工程占总资产的${fixedRatio.toFixed(2)}%，属于轻资产型公司，资产周转效率较高。`;
    } else if (fixedRatio < ANALYSIS_STANDARDS.fixedAssetsRatio.warning) {
      analysis = `公司固定资产和在建工程占总资产的${fixedRatio.toFixed(2)}%，资产结构中等。`;
    } else {
      status = 'bad';
      score = 40;
      analysis = `公司固定资产和在建工程占总资产的${fixedRatio.toFixed(2)}%，属于重资产型公司，资产较重，需要注意资产周转效率。`;
    }

    return {
      step: 8,
      name: '轻重资产分析',
      metric: '固定资产+在建工程占比',
      value: fixedRatio,
      standard: '轻资产型公司更有优势',
      status,
      score,
      analysis
    };
  }

  // 第9步：主业专注度分析
  analyzeFocus(currentData: FinancialData): StepResult {
    const investmentRatio = (currentData.investmentAssets / currentData.totalAssets) * 100;

    let status: 'good' | 'warning' | 'bad' = 'good';
    let score = 80;

    if (investmentRatio >= ANALYSIS_STANDARDS.investmentAssetsRatio.warning) {
      status = 'warning';
      score = 50;
    }
    if (investmentRatio >= ANALYSIS_STANDARDS.investmentAssetsRatio.warning * 2) {
      status = 'bad';
      score = 20;
    }

    return {
      step: 9,
      name: '主业专注度分析',
      metric: '投资类资产占比',
      value: investmentRatio,
      standard: `小于${ANALYSIS_STANDARDS.investmentAssetsRatio.good}%为主业专注`,
      status,
      score,
      analysis: this.generateFocusAnalysis(investmentRatio)
    };
  }

  private generateFocusAnalysis(ratio: number): string {
    if (ratio <= 10) {
      return `公司投资类资产占总资产的${ratio.toFixed(2)}%，公司专注于主业发展，业务结构清晰。`;
    } else if (ratio <= 20) {
      return `公司投资类资产占总资产的${ratio.toFixed(2)}%，公司有一定的投资活动，需要关注投资回报情况。`;
    } else {
      return `公司投资类资产占总资产的${ratio.toFixed(2)}%，公司投资活动较多，可能影响主业发展。`;
    }
  }

  // 第10步：存货分析
  analyzeInventory(currentData: FinancialData): StepResult {
    const inventoryRatio = (currentData.inventory / currentData.totalAssets) * 100;

    let status: 'good' | 'warning' | 'bad' = 'good';
    let score = 80;

    if (inventoryRatio >= ANALYSIS_STANDARDS.inventoryRatio.warning) {
      status = 'warning';
      score = 50;
    }
    if (inventoryRatio >= ANALYSIS_STANDARDS.inventoryRatio.warning * 2) {
      status = 'bad';
      score = 20;
    }

    return {
      step: 10,
      name: '存货分析',
      metric: '存货占比',
      value: inventoryRatio,
      standard: `小于${ANALYSIS_STANDARDS.inventoryRatio.good}%为良好`,
      status,
      score,
      analysis: this.generateInventoryAnalysis(inventoryRatio)
    };
  }

  private generateInventoryAnalysis(ratio: number): string {
    if (ratio <= 15) {
      return `公司存货占总资产的${ratio.toFixed(2)}%，存货管理较好，存货积压风险较低。`;
    } else if (ratio <= 30) {
      return `公司存货占总资产的${ratio.toFixed(2)}%，存货占比偏高，需要关注存货周转情况。`;
    } else {
      return `公司存货占总资产的${ratio.toFixed(2)}%，存货过高，存在较大的减值风险和积压风险。`;
    }
  }

  // 第11步：商誉分析
  analyzeGoodwill(currentData: FinancialData): StepResult {
    const goodwillRatio = (currentData.goodwill / currentData.totalAssets) * 100;

    let status: 'good' | 'warning' | 'bad' = 'good';
    let score = 80;

    if (goodwillRatio >= ANALYSIS_STANDARDS.goodwillRatio.warning) {
      status = 'warning';
      score = 50;
    }
    if (goodwillRatio >= ANALYSIS_STANDARDS.goodwillRatio.warning * 2) {
      status = 'bad';
      score = 20;
    }

    return {
      step: 11,
      name: '商誉分析',
      metric: '商誉占比',
      value: goodwillRatio,
      standard: `小于${ANALYSIS_STANDARDS.goodwillRatio.good}%为良好`,
      status,
      score,
      analysis: this.generateGoodwillAnalysis(goodwillRatio)
    };
  }

  private generateGoodwillAnalysis(ratio: number): string {
    if (ratio <= 10) {
      return `公司商誉占总资产的${ratio.toFixed(2)}%，商誉减值风险较低。`;
    } else if (ratio <= 20) {
      return `公司商誉占总资产的${ratio.toFixed(2)}%，商誉占比偏高，存在一定的减值风险。`;
    } else {
      return `公司商誉占总资产的${ratio.toFixed(2)}%，商誉占比过高，一旦发生减值将对公司利润产生较大冲击。`;
    }
  }

  // 第12步：营业收入增长分析
  analyzeRevenueGrowth(currentData: FinancialData, historicalData: FinancialData[]): StepResult {
    const latest = currentData;
    const previous = historicalData[historicalData.length - 2];

    const revenueGrowth = previous
      ? ((latest.revenue - previous.revenue) / previous.revenue) * 100
      : 0;

    let status: 'good' | 'warning' | 'bad' = 'warning';
    let score = 50;

    if (revenueGrowth >= ANALYSIS_STANDARDS.revenueGrowth.good) {
      status = 'good';
      score = 100;
    } else if (revenueGrowth < 0) {
      status = 'bad';
      score = 20;
    }

    return {
      step: 12,
      name: '营业收入增长分析',
      metric: '营业收入增长率',
      value: revenueGrowth,
      standard: `大于${ANALYSIS_STANDARDS.revenueGrowth.good}%为良好`,
      status,
      score,
      analysis: this.generateRevenueGrowthAnalysis(revenueGrowth)
    };
  }

  private generateRevenueGrowthAnalysis(growthRate: number): string {
    if (growthRate >= 10) {
      return `公司营业收入增长率为${growthRate.toFixed(2)}%，处于快速增长阶段，市场拓展能力强。`;
    } else if (growthRate >= 0) {
      return `公司营业收入增长率为${growthRate.toFixed(2)}%，增长趋于稳定，公司处于成熟期。`;
    } else {
      return `公司营业收入增长率为${growthRate.toFixed(2)}%，出现负增长，需要分析原因并关注公司发展前景。`;
    }
  }

  // 第13步：净利润增长分析
  analyzeNetProfitGrowth(currentData: FinancialData, historicalData: FinancialData[]): StepResult {
    const latest = currentData;
    const previous = historicalData[historicalData.length - 2];

    const netProfitGrowth = previous
      ? ((latest.netProfit - previous.netProfit) / previous.netProfit) * 100
      : 0;

    let status: 'good' | 'warning' | 'bad' = 'warning';
    let score = 50;

    if (netProfitGrowth >= 10) {
      status = 'good';
      score = 100;
    } else if (netProfitGrowth < 0) {
      status = 'bad';
      score = 20;
    }

    return {
      step: 13,
      name: '净利润增长分析',
      metric: '净利润增长率',
      value: netProfitGrowth,
      standard: '大于10%为良好',
      status,
      score,
      analysis: this.generateNetProfitGrowthAnalysis(netProfitGrowth)
    };
  }

  private generateNetProfitGrowthAnalysis(growthRate: number): string {
    if (growthRate >= 10) {
      return `公司净利润增长率为${growthRate.toFixed(2)}%，盈利能力强，利润增长良好。`;
    } else if (growthRate >= 0) {
      return `公司净利润增长率为${growthRate.toFixed(2)}%，盈利能力稳定。`;
    } else {
      return `公司净利润增长率为${growthRate.toFixed(2)}%，盈利下降，需要关注原因。`;
    }
  }

  // 第14步：ROE分析
  analyzeROE(currentData: FinancialData): StepResult {
    const roe = currentData.roe;

    let status: 'good' | 'warning' | 'bad' = 'good';
    let score = 70;

    if (roe >= ANALYSIS_STANDARDS.roe.good) {
      status = 'good';
      score = 100;
    } else if (roe >= ANALYSIS_STANDARDS.roe.warning) {
      status = 'warning';
      score = 60;
    } else {
      status = 'bad';
      score = 30;
    }

    return {
      step: 14,
      name: 'ROE分析',
      metric: '净资产收益率(ROE)',
      value: roe,
      standard: `大于${ANALYSIS_STANDARDS.roe.good}%为良好`,
      status,
      score,
      analysis: this.generateROEAnalysis(roe)
    };
  }

  private generateROEAnalysis(roe: number): string {
    if (roe >= 15) {
      return `公司ROE为${roe.toFixed(2)}%，为优秀水平，说明公司为股东创造的回报较高。`;
    } else if (roe >= 10) {
      return `公司ROE为${roe.toFixed(2)}%，处于一般水平，具有一定的投资价值。`;
    } else {
      return `公司ROE为${roe.toFixed(2)}%，较低，股东回报不佳。`;
    }
  }

  // 第15步：净利润现金含量分析
  analyzeCashToNetProfit(currentData: FinancialData): StepResult {
    const cashRatio = (currentData.cashFromOps / currentData.netProfit) * 100;

    let status: 'good' | 'warning' | 'bad' = 'good';
    let score = 70;

    if (cashRatio >= ANALYSIS_STANDARDS.cashToNetProfitRatio.good) {
      status = 'good';
      score = 100;
    } else if (cashRatio >= ANALYSIS_STANDARDS.cashToNetProfitRatio.warning) {
      status = 'warning';
      score = 50;
    } else {
      status = 'bad';
      score = 20;
    }

    return {
      step: 15,
      name: '净利润现金含量分析',
      metric: '净利润现金含量',
      value: cashRatio,
      standard: `大于${ANALYSIS_STANDARDS.cashToNetProfitRatio.good}%为良好`,
      status,
      score,
      analysis: this.generateCashToNetProfitAnalysis(cashRatio)
    };
  }

  private generateCashToNetProfitAnalysis(cashRatio: number): string {
    if (cashRatio >= 80) {
      return `公司净利润现金含量为${cashRatio.toFixed(2)}%，利润质量较高，现金流充裕。`;
    } else if (cashRatio >= 50) {
      return `公司净利润现金含量为${cashRatio.toFixed(2)}%，利润质量一般，需要关注现金流情况。`;
    } else {
      return `公司净利润现金含量为${cashRatio.toFixed(2)}%，利润质量较差，大部分利润可能是账面利润。`;
    }
  }

  // 综合分析
  analyzeStock(stockInfo: StockInfo, historicalData: FinancialData[]): AnalysisResult {
    const currentData = historicalData[0];
    const stepResults: StepResult[] = [];

    // 执行所有分析步骤
    stepResults.push(this.analyzeTotalAssets(currentData, historicalData));
    stepResults.push(this.analyzeDebtRatio(currentData));
    stepResults.push(this.analyzeCashAndDebt(currentData));
    stepResults.push(this.analyzeBusinessPower(currentData));
    stepResults.push(this.analyzeReceivables(currentData));
    stepResults.push(this.analyzeAssetType(currentData));
    stepResults.push(this.analyzeFocus(currentData));
    stepResults.push(this.analyzeInventory(currentData));
    stepResults.push(this.analyzeGoodwill(currentData));
    stepResults.push(this.analyzeRevenueGrowth(currentData, historicalData));
    stepResults.push(this.analyzeNetProfitGrowth(currentData, historicalData));
    stepResults.push(this.analyzeROE(currentData));
    stepResults.push(this.analyzeCashToNetProfit(currentData));

    this.stepResults = stepResults;

    // 计算综合评分
    const totalScore = stepResults.reduce((sum, step) => sum + step.score, 0);
    const avgScore = totalScore / stepResults.length;

    // 计算各项能力评分
    const totalAssetsScore = this.calculateCategoryScore([3]);
    const debtScore = this.calculateCategoryScore([4, 5]);
    const cashScore = this.calculateCategoryScore([15]);
    const growthScore = this.calculateCategoryScore([12, 13]);
    const qualityScore = this.calculateCategoryScore([6, 7, 8, 9, 10, 11, 14]);

    // 确定风险等级
    let riskLevel: 'low' | 'medium' | 'high' = 'low';
    if (avgScore < 40) {
      riskLevel = 'high';
    } else if (avgScore < 60) {
      riskLevel = 'medium';
    }

    // 生成优势和劣势
    const strengths = stepResults.filter(s => s.status === 'good').map(s => s.analysis);
    const weaknesses = stepResults.filter(s => s.status === 'bad').map(s => s.analysis);
    const warnings = stepResults.filter(s => s.status === 'warning').map(s => s.analysis);

    // 生成投资建议
    const recommendation = this.generateRecommendation(avgScore, riskLevel, strengths.length, weaknesses.length);

    return {
      score: Math.round(avgScore),
      totalAssetsScore,
      debtScore,
      cashScore,
      growthScore,
      qualityScore,
      recommendation,
      riskLevel,
      strengths,
      weaknesses
    };
  }

  private calculateCategoryScore(steps: number[]): number {
    const categorySteps = this.stepResults.filter(s => steps.includes(s.step));
    if (categorySteps.length === 0) return 0;

    const totalScore = categorySteps.reduce((sum, step) => sum + step.score, 0);
    return Math.round(totalScore / categorySteps.length);
  }

  private generateRecommendation(avgScore: number, riskLevel: string, strengthsCount: number, weaknessesCount: number): string {
    let recommendation = '';

    if (avgScore >= 80) {
      recommendation = '★★★★★ 优秀公司 - 财务状况优良，建议关注';
    } else if (avgScore >= 70) {
      recommendation = '★★★★☆ 良好公司 - 财务状况较好，可以关注';
    } else if (avgScore >= 60) {
      recommendation = '★★★☆☆ 一般公司 - 财务状况一般，谨慎关注';
    } else if (avgScore >= 50) {
      recommendation = '★★☆☆☆ 较弱公司 - 财务状况存在一定问题，建议观望';
    } else {
      recommendation = '★☆☆☆☆ 较差公司 - 财务状况较差，建议回避';
    }

    return recommendation;
  }

  // 生成完整报告
  generateReport(stockInfo: StockInfo, historicalData: FinancialData[], analysisResult: AnalysisResult): StockAnalysisReport {
    const currentData = historicalData[0];

    // 构建报告各部分
    const financialHealth: ReportSection = {
      title: '财务健康度分析',
      content: this.stepResults.find(s => s.step === 3)?.analysis || '',
      score: this.stepResults.find(s => s.step === 3)?.score,
      status: this.stepResults.find(s => s.step === 3)?.status,
      metrics: [
        {
          name: '总资产',
          value: `${(currentData.totalAssets / 100000000).toFixed(2)}亿元`,
          standard: '规模越大越好',
          status: 'good'
        },
        {
          name: '总资产增长率',
          value: `${this.stepResults.find(s => s.step === 3)?.value.toFixed(2)}%`,
          standard: '大于10%为良好',
          status: this.stepResults.find(s => s.step === 3)?.status || 'warning'
        }
      ]
    };

    const debtAnalysis: ReportSection = {
      title: '债务风险分析',
      content: this.stepResults.find(s => s.step === 4)?.analysis || '',
      score: this.stepResults.find(s => s.step === 4)?.score,
      status: this.stepResults.find(s => s.step === 4)?.status,
      metrics: [
        {
          name: '资产负债率',
          value: `${this.stepResults.find(s => s.step === 4)?.value.toFixed(2)}%`,
          standard: '小于70%为安全',
          status: this.stepResults.find(s => s.step === 4)?.status || 'warning'
        },
        {
          name: '准货币资金/有息负债',
          value: `${(currentData.currencyFunds + currentData.tradingAssets) / (currentData.totalLiabilities * 0.6) * 100 > 100 ? '充足' : '不足'}`,
          standard: '充足为良好',
          status: this.stepResults.find(s => s.step === 5)?.status || 'warning'
        }
      ]
    };

    const cashFlowAnalysis: ReportSection = {
      title: '现金流分析',
      content: this.stepResults.find(s => s.step === 15)?.analysis || '',
      score: this.stepResults.find(s => s.step === 15)?.score,
      status: this.stepResults.find(s => s.step === 15)?.status,
      metrics: [
        {
          name: '净利润现金含量',
          value: `${this.stepResults.find(s => s.step === 15)?.value.toFixed(2)}%`,
          standard: '大于80%为良好',
          status: this.stepResults.find(s => s.step === 15)?.status || 'warning'
        }
      ]
    };

    const growthAnalysis: ReportSection = {
      title: '成长性分析',
      content: this.stepResults.find(s => s.step === 12)?.analysis || '',
      score: this.stepResults.find(s => s.step === 12)?.score,
      status: this.stepResults.find(s => s.step === 12)?.status,
      metrics: [
        {
          name: '营业收入增长率',
          value: `${this.stepResults.find(s => s.step === 12)?.value.toFixed(2)}%`,
          standard: '大于10%为良好',
          status: this.stepResults.find(s => s.step === 12)?.status || 'warning'
        },
        {
          name: '净利润增长率',
          value: `${this.stepResults.find(s => s.step === 13)?.value.toFixed(2)}%`,
          standard: '大于10%为良好',
          status: this.stepResults.find(s => s.step === 13)?.status || 'warning'
        }
      ]
    };

    const operationQuality: ReportSection = {
      title: '经营质量分析',
      content: '',
      score: this.stepResults.find(s => s.step === 14)?.score,
      status: this.stepResults.find(s => s.step === 14)?.status,
      metrics: [
        {
          name: 'ROE',
          value: `${this.stepResults.find(s => s.step === 14)?.value.toFixed(2)}%`,
          standard: '大于15%为优秀',
          status: this.stepResults.find(s => s.step === 14)?.status || 'warning'
        },
        {
          name: '应收账款占比',
          value: `${this.stepResults.find(s => s.step === 7)?.value.toFixed(2)}%`,
          standard: '小于10%为良好',
          status: this.stepResults.find(s => s.step === 7)?.status || 'warning'
        },
        {
          name: '存货占比',
          value: `${this.stepResults.find(s => s.step === 10)?.value.toFixed(2)}%`,
          standard: '小于15%为良好',
          status: this.stepResults.find(s => s.step === 10)?.status || 'warning'
        },
        {
          name: '轻重资产类型',
          value: `${this.stepResults.find(s => s.step === 8)?.value.toFixed(2)}%`,
          standard: '轻资产更优',
          status: this.stepResults.find(s => s.step === 8)?.status || 'warning'
        },
        {
          name: '主业专注度',
          value: `${this.stepResults.find(s => s.step === 9)?.value.toFixed(2)}%`,
          standard: '小于10%为专注',
          status: this.stepResults.find(s => s.step === 9)?.status || 'warning'
        },
        {
          name: '商誉占比',
          value: `${this.stepResults.find(s => s.step === 11)?.value.toFixed(2)}%`,
          standard: '小于10%为良好',
          status: this.stepResults.find(s => s.step === 11)?.status || 'warning'
        }
      ]
    };

    return {
      basicInfo: {
        companyName: stockInfo.name,
        stockCode: stockInfo.symbol,
        industry: stockInfo.industry,
        listDate: stockInfo.listDate,
        reportDate: new Date().toISOString().split('T')[0]
      },
      financialHealth,
      debtAnalysis,
      cashFlowAnalysis,
      growthAnalysis,
      operationQuality,
      valuation: {
        peRatio: 0,
        pbRatio: 0,
        marketCap: 0,
        reasonablePE: 15,
        valuationStatus: 'fair'
      },
      overallAssessment: analysisResult
    };
  }
}

export const analysisEngine = new AnalysisEngine();
