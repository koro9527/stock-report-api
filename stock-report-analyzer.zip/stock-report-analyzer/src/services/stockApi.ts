// 股票数据API服务 - 连接到后端API
import { StockInfo, YearlyFinancialData, FinancialData } from '@/types/stock';

// API基础地址 - 使用LocalTunnel云端后端
const API_BASE_URL = 'https://legal-ads-flow.loca.lt/api';

interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  timestamp: string;
}

interface BackendStockInfo {
  symbol: string;
  name: string;
  industry: string;
  area: string;
  listDate: string;
  market: string;
  exchange: string;
  currency: string;
  historicalData: YearlyFinancialData[];
  lastUpdated: string;
  dataSource: string;
}

// 转换后端数据格式为前端格式
const transformBackendData = (backendData: BackendStockInfo): StockInfo => {
  const latestYear = backendData.historicalData[0];
  const previousYear = backendData.historicalData[1];

  // 计算增长率
  const totalAssetsGrowth = previousYear && latestYear
    ? ((latestYear.metrics.totalAssets - previousYear.metrics.totalAssets) / previousYear.metrics.totalAssets) * 100
    : 0;

  const revenueGrowth = previousYear && latestYear
    ? ((latestYear.metrics.revenue - previousYear.metrics.revenue) / previousYear.metrics.revenue) * 100
    : 0;

  const netProfitGrowth = previousYear && latestYear
    ? ((latestYear.metrics.netProfit - previousYear.metrics.netProfit) / previousYear.metrics.netProfit) * 100
    : 0;

  return {
    symbol: backendData.symbol,
    name: backendData.name,
    industry: backendData.industry,
    area: backendData.area,
    listDate: backendData.listDate,
    market: backendData.market,
    totalAssets: latestYear?.metrics.totalAssets || 0,
    totalAssetsGrowth,
    totalLiabilities: latestYear?.metrics.totalLiabilities || 0,
    debtAssetRatio: latestYear?.metrics.debtAssetRatio || 0,
    currencyFunds: latestYear?.metrics.currencyFunds || 0,
    tradingAssets: latestYear?.metrics.tradingAssets || 0,
    interestLiabilities: latestYear?.metrics.interestLiabilities || 0,
    netAssets: latestYear?.metrics.totalEquity || 0,
    revenue: latestYear?.metrics.revenue || 0,
    revenueGrowth,
    netProfit: latestYear?.metrics.netProfit || 0,
    netProfitGrowth,
    roe: latestYear?.metrics.roe || 0,
    cashFromOps: latestYear?.metrics.cashFromOps || 0,
    cashToNetProfitRatio: latestYear?.metrics.netProfit
      ? (latestYear.metrics.cashFromOps / latestYear.metrics.netProfit) * 100
      : 0,
    receivables: latestYear?.metrics.receivables || 0,
    contractAssets: latestYear?.metrics.contractAssets || 0,
    inventory: latestYear?.metrics.inventory || 0,
    goodwill: latestYear?.metrics.goodwill || 0,
    fixedAssets: latestYear?.metrics.fixedAssets || 0,
    constructionInProgress: latestYear?.metrics.constructionInProgress || 0,
    investmentAssets: latestYear?.metrics.investmentAssets || 0,
    advanceReceivables: latestYear?.metrics.advanceReceivables || 0,
    payableAccounts: latestYear?.metrics.payableAccounts || 0,
    historicalData: backendData.historicalData
  };
};

// 将YearlyFinancialData转换为FinancialData
const convertToFinancialData = (yearlyData: YearlyFinancialData[]): FinancialData[] => {
  return yearlyData.map(yearData => ({
    year: yearData.year,
    totalAssets: yearData.metrics.totalAssets,
    totalLiabilities: yearData.metrics.totalLiabilities,
    currencyFunds: yearData.metrics.currencyFunds,
    tradingAssets: yearData.metrics.tradingAssets,
    receivables: yearData.metrics.receivables,
    contractAssets: yearData.metrics.contractAssets,
    inventory: yearData.metrics.inventory,
    goodwill: yearData.metrics.goodwill,
    fixedAssets: yearData.metrics.fixedAssets,
    constructionInProgress: yearData.metrics.constructionInProgress,
    investmentAssets: yearData.metrics.investmentAssets,
    advanceReceivables: yearData.metrics.advanceReceivables,
    payableAccounts: yearData.metrics.payableAccounts,
    revenue: yearData.metrics.revenue,
    netProfit: yearData.metrics.netProfit,
    cashFromOps: yearData.metrics.cashFromOps,
    roe: yearData.metrics.roe,
    totalEquity: yearData.metrics.totalEquity
  }));
};

export class StockApiService {
  private static instance: StockApiService;

  private constructor() {}

  static getInstance(): StockApiService {
    if (!StockApiService.instance) {
      StockApiService.instance = new StockApiService();
    }
    return StockApiService.instance;
  }

  // 从后端获取股票数据
  async getStockInfo(symbol: string): Promise<StockInfo | null> {
    try {
      console.log(`从后端API获取股票数据: ${symbol}`);

      const response = await fetch(`${API_BASE_URL}/stocks/${symbol}?fetch=true`);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const result: ApiResponse<BackendStockInfo> = await response.json();

      if (result.success && result.data) {
        console.log(`成功获取股票 ${symbol} (${result.data.name}) 的数据`);
        return transformBackendData(result.data);
      } else {
        console.warn(`获取股票 ${symbol} 失败: ${result.error}`);
        return null;
      }

    } catch (error) {
      console.error('获取股票信息失败:', error);
      throw error;
    }
  }

  // 获取历史财务数据
  async getHistoricalFinancials(symbol: string, years: number = 5): Promise<FinancialData[]> {
    try {
      const stockInfo = await this.getStockInfo(symbol);

      if (stockInfo && stockInfo.historicalData) {
        return convertToFinancialData(stockInfo.historicalData.slice(0, years));
      }

      return [];

    } catch (error) {
      console.error('获取历史财务数据失败:', error);
      throw error;
    }
  }

  // 获取支持的股票列表
  async getSupportedStocks(): Promise<{ symbol: string; name: string }[]> {
    try {
      const response = await fetch(`${API_BASE_URL}/stocks/list/all`);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const result = await response.json();

      if (result.success && result.data) {
        return result.data;
      }

      return [];

    } catch (error) {
      console.error('获取股票列表失败:', error);
      // 返回默认股票列表
      return [
        { symbol: '600519', name: '贵州茅台' },
        { symbol: '600036', name: '招商银行' },
        { symbol: '000001', name: '平安银行' },
        { symbol: '300750', name: '宁德时代' },
        { symbol: '000333', name: '美的集团' },
        { symbol: '002594', name: '比亚迪' }
      ];
    }
  }

  // 搜索股票
  async searchStocks(keyword: string): Promise<{ symbol: string; name: string }[]> {
    try {
      const response = await fetch(`${API_BASE_URL}/stocks/search/${encodeURIComponent(keyword)}`);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const result = await response.json();

      if (result.success && result.data) {
        return result.data;
      }

      return [];

    } catch (error) {
      console.error('搜索股票失败:', error);
      return [];
    }
  }

  // 获取股票分析结果
  async analyzeStock(symbol: string): Promise<any> {
    try {
      const response = await fetch(`${API_BASE_URL}/stocks/${symbol}/analysis`);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const result = await response.json();

      if (result.success && result.data) {
        return result.data;
      }

      return null;

    } catch (error) {
      console.error('分析股票失败:', error);
      throw error;
    }
  }

  // 检查后端是否可用
  async checkBackendHealth(): Promise<boolean> {
    try {
      const response = await fetch(`${API_BASE_URL.replace('/api', '')}/health`);
      const result = await response.json();
      return result.status === 'healthy';
    } catch (error) {
      console.error('后端健康检查失败:', error);
      return false;
    }
  }
}

export const stockApi = StockApiService.getInstance();
