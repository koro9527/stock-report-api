// 更新所有缓存数据脚本
import dotenv from 'dotenv';
import path from 'path';
import SchedulerService from '../services/scheduler';

dotenv.config({ path: path.join(__dirname, '..', '..', '.env') });

async function updateAllData() {
  const scheduler = new SchedulerService();

  console.log('开始更新所有股票数据...\n');

  try {
    const results = await scheduler.runUpdateJob();

    console.log(`\n========================================`);
    console.log(`更新完成: 成功 ${results.success}, 失败 ${results.failed}`);
    console.log(`========================================`);

    process.exit(results.failed > 0 ? 1 : 0);
  } catch (error) {
    console.error('更新数据时出错:', error);
    process.exit(1);
  }
}

updateAllData();
