// 批量获取股票数据脚本
import dotenv from 'dotenv';
import path from 'path';
import THSScraperService from '../services/thsScraper';
import DataStoreService from '../services/dataStore';

dotenv.config({ path: path.join(__dirname, '..', '..', '.env') });

async function fetchStockData(symbols: string[]) {
  const scraper = new THSScraperService();
  const dataStore = new DataStoreService();

  console.log(`开始获取 ${symbols.length} 只股票的数据...\n`);

  let success = 0;
  let failed = 0;

  for (const symbol of symbols) {
    try {
      console.log(`正在获取: ${symbol}...`);

      const stockData = await scraper.getCompleteStockData(symbol, { forceUpdate: true });

      if (stockData) {
        await dataStore.saveStockData(stockData);
        console.log(`✓ 成功获取 ${symbol} (${stockData.name}) 的数据`);
        success++;
      } else {
        console.log(`✗ 获取 ${symbol} 数据失败`);
        failed++;
      }

      // 避免请求过快
      await new Promise((resolve) => setTimeout(resolve, 2000));
    } catch (error) {
      console.error(`✗ 获取 ${symbol} 数据时出错:`, error);
      failed++;
    }
  }

  console.log(`\n========================================`);
  console.log(`获取完成: 成功 ${success}, 失败 ${failed}`);
  console.log(`========================================`);

  process.exit(failed > 0 ? 1 : 0);
}

// 从命令行参数获取股票代码
const symbols = process.argv.slice(2);

if (symbols.length === 0) {
  console.log('用法: ts-node src/scripts/fetchStockData.ts <股票代码1> <股票代码2> ...');
  console.log('示例: ts-node src/scripts/fetchStockData.ts 600519 000001 300750');
  process.exit(0);
}

fetchStockData(symbols);
