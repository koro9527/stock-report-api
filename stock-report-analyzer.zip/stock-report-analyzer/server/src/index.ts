// 主服务器入口
import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';

// 加载环境变量
dotenv.config({ path: path.join(__dirname, '..', '.env') });

import logger from './utils/logger';
import stockRoutes from './routes/stocks';
import SchedulerService from './services/scheduler';

const app = express();
const PORT = process.env.PORT || 3001;

// 中间件
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// 请求日志
app.use((req: Request, res: Response, next: NextFunction) => {
  logger.info(`${req.method} ${req.path}`);
  next();
});

// 健康检查
app.get('/health', (req: Request, res: Response) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
  });
});

// API版本信息
app.get('/api', (req: Request, res: Response) => {
  res.json({
    name: '股票年报数据服务 API',
    version: '1.0.0',
    endpoints: {
      stocks: {
        'GET /api/stocks/:symbol': '获取股票数据',
        'GET /api/stocks/search/:keyword': '搜索股票',
        'GET /api/stocks/list/all': '获取所有股票列表',
        'GET /api/stocks/list/watchlist': '获取观察列表',
        'POST /api/stocks/fetch': '从同花顺获取数据',
        'POST /api/stocks/update/:symbol': '手动更新单只股票',
        'POST /api/stocks/watchlist': '添加股票到观察列表',
        'DELETE /api/stocks/watchlist': '从观察列表移除',
        'DELETE /api/stocks/:symbol': '删除股票数据',
        'GET /api/stocks/stats/all': '获取统计信息',
      },
      scheduler: {
        'GET /api/scheduler/status': '获取调度状态',
        'POST /api/scheduler/run': '手动触发更新任务',
      },
    },
  });
});

// 股票数据路由
app.use('/api/stocks', stockRoutes);

// 调度服务路由
const scheduler = new SchedulerService();

app.get('/api/scheduler/status', (req: Request, res: Response) => {
  const status = scheduler.getStatus();
  res.json({
    success: true,
    data: status,
    timestamp: new Date().toISOString(),
  });
});

app.post('/api/scheduler/run', async (req: Request, res: Response) => {
  try {
    logger.info('手动触发更新任务');
    const results = await scheduler.runUpdateJob();
    res.json({
      success: true,
      data: results,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    logger.error('手动触发更新任务失败:', error);
    res.status(500).json({
      success: false,
      error: '执行更新任务失败',
      timestamp: new Date().toISOString(),
    });
  }
});

app.post('/api/scheduler/start', (req: Request, res: Response) => {
  scheduler.start();
  res.json({
    success: true,
    message: '调度服务已启动',
    timestamp: new Date().toISOString(),
  });
});

app.post('/api/scheduler/stop', (req: Request, res: Response) => {
  scheduler.stop();
  res.json({
    success: true,
    message: '调度服务已停止',
    timestamp: new Date().toISOString(),
  });
});

// 404处理
app.use((req: Request, res: Response) => {
  res.status(404).json({
    success: false,
    error: '请求的资源不存在',
    timestamp: new Date().toISOString(),
  });
});

// 错误处理
app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  logger.error('服务器错误:', err);
  res.status(500).json({
    success: false,
    error: '服务器内部错误',
    timestamp: new Date().toISOString(),
  });
});

// 启动服务器
const server = app.listen(PORT, () => {
  logger.info(`========================================`);
  logger.info(`  股票年报数据服务启动成功`);
  logger.info(`  端口: ${PORT}`);
  logger.info(`  环境: ${process.env.NODE_ENV || 'development'}`);
  logger.info(`========================================`);

  // 启动自动更新调度
  scheduler.start();
});

// 优雅关闭
process.on('SIGTERM', () => {
  logger.info('收到 SIGTERM 信号，正在关闭服务器...');
  scheduler.stop();
  server.close(() => {
    logger.info('服务器已关闭');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  logger.info('收到 SIGINT 信号，正在关闭服务器...');
  scheduler.stop();
  server.close(() => {
    logger.info('服务器已关闭');
    process.exit(0);
  });
});

export default app;
