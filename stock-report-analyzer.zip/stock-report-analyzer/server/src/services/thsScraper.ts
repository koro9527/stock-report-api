// 同花顺数据爬取服务 - 增强版
import axios, { AxiosInstance } from 'axios';
import * as cheerio from 'cheerio';
import fs from 'fs';
import path from 'path';
import { StockInfo, YearlyFinancialData, FinancialMetrics, FetchOptions, StockSearchResult } from '../types/stock';
import logger from '../utils/logger';

export class THSScraperService {
  private client: AxiosInstance;
  private baseUrl: string;
  private requestDelay: number;
  private useSampleData: boolean;
  private sampleDataPath: string;

  constructor() {
    this.baseUrl = process.env.THS_BASE_URL || 'https://basic.10jqka.com.cn';
    this.requestDelay = parseInt(process.env.THS_API_DELAY || '2000');
    this.useSampleData = process.env.USE_SAMPLE_DATA === 'true';
    this.sampleDataPath = process.env.SAMPLE_DATA_PATH || 'data/sample';

    this.client = axios.create({
      baseURL: this.baseUrl,
      timeout: parseInt(process.env.THS_REQUEST_TIMEOUT || '30000'),
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        'Connection': 'keep-alive',
        'Referer': 'https://basic.10jqka.com.cn/',
      },
    });

    // 请求拦截器
    this.client.interceptors.request.use(
      (config) => {
        logger.debug(`请求: ${config.url}`);
        return config;
      },
      (error) => {
        logger.error('请求错误:', error);
        return Promise.reject(error);
      }
    );

    // 响应拦截器
    this.client.interceptors.response.use(
      (response) => {
        return response;
      },
      (error) => {
        logger.error('响应错误:', error.message);
        return Promise.reject(error);
      }
    );
  }

  /**
   * 延迟请求（防止被封禁）
   */
  private async delay(ms?: number): Promise<void> {
    const delayTime = ms || this.requestDelay;
    return new Promise((resolve) => setTimeout(resolve, delayTime));
  }

  /**
   * 获取股票基础信息
   */
  async getStockInfo(symbol: string): Promise<StockInfo | null> {
    // 如果启用了示例数据模式，直接返回示例数据
    if (this.useSampleData) {
      return this.getSampleStockInfo(symbol);
    }

    try {
      await this.delay();

      logger.info(`正在获取股票 ${symbol} 的基础信息...`);

      const url = `${this.baseUrl}/${symbol}/`;
      logger.info(`请求URL: ${url}`);

      const response = await this.client.get(url);

      if (response.status !== 200) {
        throw new Error(`HTTP ${response.status}`);
      }

      const $ = cheerio.load(response.data);
      const stockInfo = this.parseStockInfo($, symbol);

      if (stockInfo) {
        logger.info(`成功获取股票 ${symbol} (${stockInfo.name}) 的基础信息`);
      } else {
        logger.warn(`解析股票 ${symbol} 信息失败，尝试使用示例数据`);
        return this.getSampleStockInfo(symbol);
      }

      return stockInfo;
    } catch (error) {
      logger.error(`获取股票 ${symbol} 信息失败:`, error);
      logger.warn(`切换到示例数据模式`);
      return this.getSampleStockInfo(symbol);
    }
  }

  /**
   * 解析股票基础信息页面 - 增强版
   */
  private parseStockInfo($: cheerio.CheerioAPI, symbol: string): StockInfo | null {
    try {
      // 股票名称 - 多种选择器尝试
      let name = '';
      const nameSelectors = [
        'div.stock-name h1 a',
        'h1.main-title',
        'div.basic-info h1',
        'div.stock Fundamentals h1',
        '.stock-name h1',
        '#name',
        '.name',
        'h1',
        '[class*="name"]',
      ];

      for (const selector of nameSelectors) {
        name = $(selector).first().text().trim();
        if (name) break;
      }

      if (!name) {
        logger.warn(`无法通过选择器获取股票 ${symbol} 的名称`);
        return null;
      }

      logger.debug(`获取到股票名称: ${name}`);

      // 行业 - 多种选择器尝试
      let industry = '';
      const industrySelectors = [
        'div.industry a',
        'span.industry',
        '[class*="industry"]',
        '[id*="industry"]',
        'div[class*="industry"]',
      ];

      for (const selector of industrySelectors) {
        industry = $(selector).first().text().trim();
        if (industry) break;
      }

      // 地区
      let area = '';
      const areaSelectors = [
        'div.area',
        'span.area',
        '[class*="area"]',
        '[id*="area"]',
      ];

      for (const selector of areaSelectors) {
        area = $(selector).first().text().trim();
        if (area) break;
      }

      // 上市日期
      let listDate = '';
      const dateSelectors = [
        'div.list-date',
        'span.list-date',
        '[class*="list-date"]',
        '[class*="listDate"]',
      ];

      for (const selector of dateSelectors) {
        listDate = $(selector).first().text().trim();
        if (listDate) break;
      }

      // 市场类型
      const market = this.detectMarket(symbol);

      // 交易所
      const exchange = this.detectExchange(symbol);

      return {
        symbol,
        name,
        industry,
        area,
        listDate,
        market,
        exchange,
        currency: 'CNY',
        historicalData: [],
        lastUpdated: new Date().toISOString(),
        dataSource: '同花顺',
      };
    } catch (error) {
      logger.error(`解析股票 ${symbol} 信息失败:`, error);
      return null;
    }
  }

  /**
   * 获取股票历史财务数据
   */
  async getHistoricalFinancials(symbol: string, options?: FetchOptions): Promise<YearlyFinancialData[]> {
    // 如果启用了示例数据模式，直接返回示例数据
    if (this.useSampleData) {
      return this.getSampleFinancialData(symbol);
    }

    try {
      await this.delay();

      logger.info(`正在获取股票 ${symbol} 的历史财务数据...`);

      const url = `${this.baseUrl}/${symbol}/finance/`;
      logger.info(`请求URL: ${url}`);

      const response = await this.client.get(url);

      if (response.status !== 200) {
        throw new Error(`HTTP ${response.status}`);
      }

      const $ = cheerio.load(response.data);
      const yearlyData = this.parseFinancialData($, options);

      if (yearlyData.length > 0) {
        logger.info(`成功获取股票 ${symbol} 的 ${yearlyData.length} 年财务数据`);
      } else {
        logger.warn(`未获取到股票 ${symbol} 的财务数据，尝试使用示例数据`);
        return this.getSampleFinancialData(symbol);
      }

      return yearlyData;
    } catch (error) {
      logger.error(`获取股票 ${symbol} 财务数据失败:`, error);
      logger.warn(`切换到示例数据模式`);
      return this.getSampleFinancialData(symbol);
    }
  }

  /**
   * 解析财务数据页面 - 增强版
   */
  private parseFinancialData($: cheerio.CheerioAPI, options?: FetchOptions): YearlyFinancialData[] {
    const data: YearlyFinancialData[] = [];

    try {
      // 多种表格选择器尝试
      let tableRows: cheerio.Cheerio = $();
      const tableSelectors = [
        'table.finance-table tbody tr',
        'table tbody tr',
        '[class*="finance"] table tbody tr',
        '.data-table tbody tr',
        'table.data tbody tr',
      ];

      for (const selector of tableSelectors) {
        tableRows = $(selector);
        if (tableRows.length > 0) {
          logger.debug(`使用选择器: ${selector}, 找到 ${tableRows.length} 行`);
          break;
        }
      }

      if (tableRows.length === 0) {
        logger.warn('未找到财务数据表格');
        return data;
      }

      // 获取表头（年份）- 多种选择器尝试
      const headers: number[] = [];
      const headerSelectors = [
        'table.finance-table thead th',
        'table thead th',
        'thead th',
        '[class*="header"] th',
      ];

      for (const selector of headerSelectors) {
        $(selector).each((i, el) => {
          const yearText = $(el).text().trim();
          const year = parseInt(yearText);
          if (!isNaN(year) && year > 2000 && year <= 2025) {
            headers.push(year);
          }
        });
        if (headers.length > 0) break;
      }

      if (headers.length === 0) {
        logger.warn('未找到年份表头');
        return data;
      }

      logger.debug(`找到年份: ${headers.join(', ')}`);

      // 指标名称到字段的映射
      const metricMapping: Record<string, keyof FinancialMetrics> = {
        '总资产': 'totalAssets',
        '总负债': 'totalLiabilities',
        '货币资金': 'currencyFunds',
        '交易性金融资产': 'tradingAssets',
        '应收账款': 'receivables',
        '存货': 'inventory',
        '固定资产': 'fixedAssets',
        '营业收入': 'revenue',
        '净利润': 'netProfit',
        '净资产收益率': 'roe',
        '资产负债率': 'debtAssetRatio',
      };

      // 解析每行数据
      const metricsData: Record<string, Record<number, string>> = {};

      tableRows.each((rowIndex, row) => {
        const rowCells = $(row).find('td');
        if (rowCells.length < 2) return;

        const metricName = $(rowCells[0]).text().trim();
        const metricKey = metricMapping[metricName];

        if (!metricKey) return;

        rowCells.each((colIndex, cell) => {
          if (colIndex === 0) return; // 跳过第一列（指标名称）

          const yearIndex = colIndex - 1;
          if (yearIndex < headers.length) {
            const year = headers[yearIndex];
            const value = $(cell).text().trim();

            if (!metricsData[metricKey]) {
              metricsData[metricKey] = {};
            }
            metricsData[metricKey][year] = value;
          }
        });
      });

      // 构建年度数据对象
      for (const year of headers) {
        if (options?.years && !options.years.includes(year)) {
          continue;
        }

        const metrics: FinancialMetrics = {
          totalAssets: this.parseNumber(metricsData.totalAssets?.[year]),
          totalLiabilities: this.parseNumber(metricsData.totalLiabilities?.[year]),
          currencyFunds: this.parseNumber(metricsData.currencyFunds?.[year]),
          tradingAssets: this.parseNumber(metricsData.tradingAssets?.[year]),
          receivables: this.parseNumber(metricsData.receivables?.[year]),
          contractAssets: this.parseNumber(metricsData.contractAssets?.[year]),
          inventory: this.parseNumber(metricsData.inventory?.[year]),
          goodwill: 0,
          fixedAssets: this.parseNumber(metricsData.fixedAssets?.[year]),
          constructionInProgress: 0,
          investmentAssets: 0,
          advanceReceivables: 0,
          payableAccounts: 0,
          interestLiabilities: 0,
          revenue: this.parseNumber(metricsData.revenue?.[year]),
          netProfit: this.parseNumber(metricsData.netProfit?.[year]),
          cashFromOps: 0,
          cashFromInvesting: 0,
          cashFromFinancing: 0,
          roe: this.parsePercent(metricsData.roe?.[year]),
          netProfitMargin: 0,
          grossProfitMargin: 0,
          revenueGrowth: 0,
          netProfitGrowth: 0,
          totalAssetsGrowth: 0,
          currentRatio: 0,
          quickRatio: 0,
          debtAssetRatio: this.parsePercent(metricsData.debtAssetRatio?.[year]),
          assetTurnover: 0,
          inventoryTurnover: 0,
          receivableTurnover: 0,
          totalEquity: 0,
          basicEPS: 0,
          dilutedEPS: 0,
        };

        // 计算衍生指标
        this.calculateDerivedMetrics(metrics);

        data.push({
          year,
          metrics,
          reportType: '年报',
        });
      }

      return data.sort((a, b) => b.year - a.year);
    } catch (error) {
      logger.error('解析财务数据失败:', error);
      return data;
    }
  }

  /**
   * 解析数值（处理万、亿等单位）
   */
  private parseNumber(value: string | number | undefined): number {
    if (typeof value === 'number') return value;
    if (!value) return 0;

    const str = String(value).trim().replace(/,/g, '');
    const lowerStr = str.toLowerCase();

    let multiplier = 1;

    if (lowerStr.includes('亿')) {
      multiplier = 100000000;
    } else if (lowerStr.includes('千万') || lowerStr.includes('千万')) {
      multiplier = 10000000;
    } else if (lowerStr.includes('万')) {
      multiplier = 10000;
    }

    const num = parseFloat(lowerStr.replace(/[^\d.-]/g, ''));
    return isNaN(num) ? 0 : num * multiplier;
  }

  /**
   * 解析百分比
   */
  private parsePercent(value: string | number | undefined): number {
    if (typeof value === 'number') return value;
    if (!value) return 0;

    const str = String(value).trim().replace(/,/g, '').replace(/%/g, '');
    const num = parseFloat(str);
    return isNaN(num) ? 0 : num;
  }

  /**
   * 计算衍生指标
   */
  private calculateDerivedMetrics(metrics: FinancialMetrics): void {
    if (metrics.totalLiabilities > 0) {
      metrics.interestLiabilities = metrics.totalLiabilities * 0.5;
    }

    metrics.totalEquity = metrics.totalAssets - metrics.totalLiabilities;

    if (metrics.revenue > 0) {
      metrics.netProfitMargin = (metrics.netProfit / metrics.revenue) * 100;
    }

    if (metrics.totalLiabilities > 0) {
      metrics.currentRatio = (metrics.currencyFunds + metrics.receivables + metrics.inventory) / metrics.totalLiabilities;
      metrics.quickRatio = (metrics.currencyFunds + metrics.receivables) / metrics.totalLiabilities;
    }

    if (metrics.totalAssets > 0) {
      metrics.assetTurnover = metrics.revenue / metrics.totalAssets;
    }

    if (metrics.inventory > 0) {
      metrics.inventoryTurnover = metrics.revenue / metrics.inventory;
    }

    if (metrics.receivables > 0) {
      metrics.receivableTurnover = metrics.revenue / metrics.receivables;
    }

    if (metrics.totalEquity > 0) {
      metrics.basicEPS = metrics.netProfit / metrics.totalEquity * 10000;
    }
  }

  /**
   * 检测市场类型
   */
  private detectMarket(symbol: string): string {
    const code = symbol.replace(/[^0-9]/g, '');

    if (code.startsWith('6') || code.startsWith('9')) {
      return '主板';
    } else if (code.startsWith('0') || code.startsWith('2') || code.startsWith('3')) {
      return '中小板';
    } else if (code.startsWith('4') || code.startsWith('8')) {
      return '创业板';
    }

    return '未知';
  }

  /**
   * 检测交易所
   */
  private detectExchange(symbol: string): string {
    const code = symbol.replace(/[^0-9]/g, '');

    if (code.startsWith('6') || code.startsWith('9')) {
      return '上海证券交易所';
    } else {
      return '深圳证券交易所';
    }
  }

  /**
   * 搜索股票
   */
  async searchStocks(keyword: string): Promise<StockSearchResult[]> {
    // 如果启用了示例数据模式，返回示例搜索结果
    if (this.useSampleData) {
      return this.getSampleSearchResults(keyword);
    }

    try {
      await this.delay();

      logger.info(`搜索股票: ${keyword}`);

      // 使用多种搜索方式尝试
      const searchUrls = [
        `${this.baseUrl}/search/${encodeURIComponent(keyword)}`,
        `${this.baseUrl}/search/?q=${encodeURIComponent(keyword)}`,
        `${this.baseUrl}/query/?sd=${encodeURIComponent(keyword)}`,
      ];

      for (const url of searchUrls) {
        try {
          const response = await this.client.get(url);
          const $ = cheerio.load(response.data);
          const results = this.parseSearchResults($);

          if (results.length > 0) {
            logger.info(`找到 ${results.length} 个匹配结果`);
            return results;
          }
        } catch (err) {
          logger.debug(`搜索URL ${url} 失败，尝试下一个`);
        }
      }

      // 返回示例搜索结果
      logger.warn(`未找到搜索结果，返回示例数据`);
      return this.getSampleSearchResults(keyword);
    } catch (error) {
      logger.error(`搜索股票 ${keyword} 失败:`, error);
      return this.getSampleSearchResults(keyword);
    }
  }

  /**
   * 解析搜索结果
   */
  private parseSearchResults($: cheerio.CheerioAPI): StockSearchResult[] {
    const results: StockSearchResult[] = [];

    try {
      const items = $('div.search-result li, div.result-list li, ul.search-list li, [class*="result"] li');

      items.each((i, el) => {
        const link = $(el).find('a');
        const symbol = link.attr('href')?.split('/')[1] || '';
        const name = link.text().trim();

        if (symbol && name && symbol.match(/^[0-9]{6}$/)) {
          results.push({
            symbol,
            name,
            market: this.detectMarket(symbol),
            exchange: this.detectExchange(symbol),
          });
        }
      });

      return results.slice(0, 20);
    } catch (error) {
      logger.error('解析搜索结果失败:', error);
      return results;
    }
  }

  /**
   * 获取完整的股票数据
   */
  async getCompleteStockData(symbol: string, options?: FetchOptions): Promise<StockInfo | null> {
    // 如果启用了示例数据模式
    if (this.useSampleData) {
      return this.getSampleStockData(symbol);
    }

    try {
      const stockInfo = await this.getStockInfo(symbol);

      if (!stockInfo) {
        logger.warn(`无法获取股票 ${symbol} 的基础信息`);
        return this.getSampleStockData(symbol);
      }

      const historicalData = await this.getHistoricalFinancials(symbol, options);

      if (historicalData.length === 0) {
        logger.warn(`股票 ${symbol} 没有找到财务数据`);
      }

      stockInfo.historicalData = historicalData;
      stockInfo.lastUpdated = new Date().toISOString();

      return stockInfo;
    } catch (error) {
      logger.error(`获取股票 ${symbol} 完整数据失败:`, error);
      return this.getSampleStockData(symbol);
    }
  }

  // ==================== 示例数据方法 ====================

  /**
   * 获取示例股票基础信息
   */
  private getSampleStockInfo(symbol: string): StockInfo | null {
    const sampleStocks: Record<string, Partial<StockInfo>> = {
      '600519': { name: '贵州茅台', industry: '酿酒食品', area: '贵州', listDate: '2001-08-27' },
      '600036': { name: '招商银行', industry: '银行', area: '深圳', listDate: '2002-04-09' },
      '000001': { name: '平安银行', industry: '银行', area: '深圳', listDate: '1991-04-03' },
      '300750': { name: '宁德时代', industry: '电气设备', area: '福建', listDate: '2018-06-11' },
      '000333': { name: '美的集团', industry: '家用电器', area: '广东', listDate: '2013-09-18' },
      '002594': { name: '比亚迪', industry: '汽车', area: '广东', listDate: '2011-06-30' },
    };

    const stock = sampleStocks[symbol];
    if (!stock) {
      logger.warn(`未找到股票 ${symbol} 的示例数据`);
      return null;
    }

    return {
      symbol,
      name: stock.name || '未知',
      industry: stock.industry || '未知',
      area: stock.area || '未知',
      listDate: stock.listDate || '未知',
      market: this.detectMarket(symbol),
      exchange: this.detectExchange(symbol),
      currency: 'CNY',
      historicalData: [],
      lastUpdated: new Date().toISOString(),
      dataSource: '示例数据',
    };
  }

  /**
   * 获取示例财务数据
   */
  private getSampleFinancialData(symbol: string): YearlyFinancialData[] {
    const currentYear = new Date().getFullYear();
    const data: YearlyFinancialData[] = [];

    // 根据股票代码生成不同的示例数据
    const baseMultiplier = this.getBaseMultiplier(symbol);

    for (let i = 0; i < 5; i++) {
      const year = currentYear - 1 - i;
      const growthFactor = Math.pow(1.08, i); // 假设每年8%增长

      const metrics: FinancialMetrics = {
        totalAssets: 1000000000000 * baseMultiplier / growthFactor,
        totalLiabilities: 200000000000 * baseMultiplier / growthFactor,
        currencyFunds: 150000000000 * baseMultiplier / growthFactor,
        tradingAssets: 50000000000 * baseMultiplier / growthFactor,
        receivables: 20000000000 * baseMultiplier / growthFactor,
        contractAssets: 5000000000 * baseMultiplier / growthFactor,
        inventory: 30000000000 * baseMultiplier / growthFactor,
        goodwill: 10000000000 * baseMultiplier / growthFactor,
        fixedAssets: 200000000000 * baseMultiplier / growthFactor,
        constructionInProgress: 30000000000 * baseMultiplier / growthFactor,
        investmentAssets: 80000000000 * baseMultiplier / growthFactor,
        advanceReceivables: 10000000000 * baseMultiplier / growthFactor,
        payableAccounts: 50000000000 * baseMultiplier / growthFactor,
        interestLiabilities: 100000000000 * baseMultiplier / growthFactor,
        revenue: 200000000000 * baseMultiplier / growthFactor,
        netProfit: 30000000000 * baseMultiplier / growthFactor,
        cashFromOps: 40000000000 * baseMultiplier / growthFactor,
        cashFromInvesting: -20000000000 * baseMultiplier / growthFactor,
        cashFromFinancing: -10000000000 * baseMultiplier / growthFactor,
        roe: 15 + Math.random() * 10,
        netProfitMargin: 12 + Math.random() * 5,
        grossProfitMargin: 30 + Math.random() * 10,
        revenueGrowth: 8 + Math.random() * 5,
        netProfitGrowth: 10 + Math.random() * 8,
        totalAssetsGrowth: 5 + Math.random() * 3,
        currentRatio: 1.5 + Math.random() * 0.5,
        quickRatio: 1.0 + Math.random() * 0.3,
        debtAssetRatio: 20 + Math.random() * 5,
        assetTurnover: 0.3 + Math.random() * 0.1,
        inventoryTurnover: 5 + Math.random() * 2,
        receivableTurnover: 10 + Math.random() * 5,
        totalEquity: 800000000000 * baseMultiplier / growthFactor,
        basicEPS: 2.5 + Math.random() * 1.5,
        dilutedEPS: 2.4 + Math.random() * 1.4,
      };

      this.calculateDerivedMetrics(metrics);

      data.push({
        year,
        metrics,
        reportType: '年报',
      });
    }

    return data;
  }

  /**
   * 获取股票基础乘数（根据行业和规模）
   */
  private getBaseMultiplier(symbol: string): number {
    const multipliers: Record<string, number> = {
      '600519': 2.5,  // 贵州茅台 - 大型蓝筹
      '600036': 3.0,  // 招商银行 - 大型银行
      '000001': 1.5,  // 平安银行 - 中型银行
      '300750': 2.0,  // 宁德时代 - 新能源龙头
      '000333': 1.8,  // 美的集团 - 家电龙头
      '002594': 1.5,  // 比亚迪 - 汽车新能源
    };

    return multipliers[symbol] || 1.0;
  }

  /**
   * 获取示例搜索结果
   */
  private getSampleSearchResults(keyword: string): StockSearchResult[] {
    const allStocks = [
      { symbol: '600519', name: '贵州茅台' },
      { symbol: '600036', name: '招商银行' },
      { symbol: '000001', name: '平安银行' },
      { symbol: '300750', name: '宁德时代' },
      { symbol: '000333', name: '美的集团' },
      { symbol: '002594', name: '比亚迪' },
    ];

    // 根据关键词过滤
    return allStocks
      .filter(s => s.name.includes(keyword) || s.symbol.includes(keyword))
      .map(s => ({
        symbol: s.symbol,
        name: s.name,
        market: this.detectMarket(s.symbol),
        exchange: this.detectExchange(s.symbol),
      }));
  }

  /**
   * 获取示例股票完整数据
   */
  private getSampleStockData(symbol: string): StockInfo | null {
    const stockInfo = this.getSampleStockInfo(symbol);
    if (!stockInfo) return null;

    stockInfo.historicalData = this.getSampleFinancialData(symbol);
    stockInfo.lastUpdated = new Date().toISOString();
    stockInfo.dataSource = '示例数据';

    return stockInfo;
  }
}

export default THSScraperService;
