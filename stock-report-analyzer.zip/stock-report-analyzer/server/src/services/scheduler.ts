// 自动更新调度服务
import cron from 'node-cron';
import THSScraperService from './thsScraper';
import DataStoreService from './dataStore';
import logger from '../utils/logger';

export class SchedulerService {
  private scraper: THSScraperService;
  private dataStore: DataStoreService;
  private cronTask: cron.ScheduledTask | null = null;
  private isRunning: boolean = false;

  constructor() {
    this.scraper = new THSScraperService();
    this.dataStore = new DataStoreService();
  }

  /**
   * 启动调度服务
   */
  start(): void {
    const enabled = process.env.AUTO_UPDATE_ENABLED === 'true';
    const cronExpression = process.env.SCHEDULE_CRON || '0 2 * * *'; // 默认每天凌晨2点

    if (!enabled) {
      logger.info('自动更新功能已禁用');
      return;
    }

    if (this.cronTask) {
      logger.warn('调度任务已在运行中');
      return;
    }

    logger.info(`启动自动更新调度任务: ${cronExpression}`);

    this.cronTask = cron.schedule(cronExpression, async () => {
      await this.runUpdateJob();
    });

    logger.info('自动更新调度服务已启动');
  }

  /**
   * 停止调度服务
   */
  stop(): void {
    if (this.cronTask) {
      this.cronTask.stop();
      this.cronTask = null;
      logger.info('自动更新调度服务已停止');
    }
  }

  /**
   * 执行更新任务
   */
  async runUpdateJob(): Promise<{ success: number; failed: number }> {
    if (this.isRunning) {
      logger.warn('更新任务正在执行中，跳过本次执行');
      return { success: 0, failed: 0 };
    }

    this.isRunning = true;
    const results = { success: 0, failed: 0 };

    try {
      logger.info('========== 开始执行自动更新任务 ==========');
      const startTime = Date.now();

      // 获取所有需要更新的股票列表
      const stocksToUpdate = await this.dataStore.getAllSymbols();

      logger.info(`需要更新的股票数量: ${stocksToUpdate.length}`);

      for (const symbol of stocksToUpdate) {
        try {
          logger.info(`正在更新股票: ${symbol}`);

          // 获取最新数据
          const stockData = await this.scraper.getCompleteStockData(symbol, {
            forceUpdate: true,
          });

          if (stockData && stockData.historicalData.length > 0) {
            // 保存到数据存储
            await this.dataStore.saveStockData(stockData);
            logger.info(`股票 ${symbol} (${stockData.name}) 更新成功`);
            results.success++;
          } else {
            logger.warn(`股票 ${symbol} 获取数据失败`);
            results.failed++;
          }

          // 避免请求过快
          await this.delay(3000);
        } catch (error) {
          logger.error(`更新股票 ${symbol} 时发生错误:`, error);
          results.failed++;
        }
      }

      const duration = Date.now() - startTime;
      logger.info(`========== 更新任务完成 ==========`);
      logger.info(`成功: ${results.success}, 失败: ${results.failed}, 耗时: ${duration}ms`);

    } catch (error) {
      logger.error('执行更新任务时发生错误:', error);
    } finally {
      this.isRunning = false;
    }

    return results;
  }

  /**
   * 手动触发单只股票更新
   */
  async updateSingleStock(symbol: string): Promise<boolean> {
    try {
      logger.info(`手动更新股票: ${symbol}`);

      const stockData = await this.scraper.getCompleteStockData(symbol, {
        forceUpdate: true,
      });

      if (stockData) {
        await this.dataStore.saveStockData(stockData);
        logger.info(`股票 ${symbol} (${stockData.name}) 更新成功`);
        return true;
      }

      return false;
    } catch (error) {
      logger.error(`手动更新股票 ${symbol} 失败:`, error);
      return false;
    }
  }

  /**
   * 添加股票到更新队列
   */
  async addToUpdateQueue(symbols: string[]): Promise<void> {
    for (const symbol of symbols) {
      await this.dataStore.addToWatchlist(symbol);
    }
    logger.info(`已添加 ${symbols.length} 只股票到更新队列`);
  }

  /**
   * 从更新队列移除
   */
  async removeFromUpdateQueue(symbols: string[]): Promise<void> {
    for (const symbol of symbols) {
      await this.dataStore.removeFromWatchlist(symbol);
    }
    logger.info(`已从更新队列移除 ${symbols.length} 只股票`);
  }

  /**
   * 获取调度状态
   */
  getStatus(): {
    running: boolean;
    taskActive: boolean;
    queuedStocks: number;
  } {
    return {
      running: this.isRunning,
      taskActive: this.cronTask !== null,
      queuedStocks: 0, // 可以从dataStore获取
    };
  }

  /**
   * 延迟函数
   */
  private delay(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}

export default SchedulerService;
