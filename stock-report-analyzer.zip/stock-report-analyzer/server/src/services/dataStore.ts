// 数据存储服务
import fs from 'fs';
import path from 'path';
import { StockInfo, YearlyFinancialData } from '../types/stock';
import logger from '../utils/logger';

interface CacheEntry {
  data: StockInfo;
  timestamp: number;
  expiresIn: number; // 毫秒
}

class DataStoreService {
  private dataDir: string;
  private cache: Map<string, CacheEntry> = new Map();
  private watchlist: Set<string> = new Set();
  private readonly CACHE_DURATION = 24 * 60 * 60 * 1000; // 24小时
  private readonly DATA_DIR = 'data';

  constructor() {
    this.dataDir = path.resolve(process.cwd(), this.DATA_DIR);
    this.ensureDirectoryExists();
    this.loadWatchlist();
    this.loadCachedData();
  }

  /**
   * 确保数据目录存在
   */
  private ensureDirectoryExists(): void {
    if (!fs.existsSync(this.dataDir)) {
      fs.mkdirSync(this.dataDir, { recursive: true });
      logger.info(`创建数据目录: ${this.dataDir}`);
    }
  }

  /**
   * 加载观察列表
   */
  private loadWatchlist(): void {
    const watchlistPath = path.join(this.dataDir, 'watchlist.json');

    if (fs.existsSync(watchlistPath)) {
      try {
        const data = JSON.parse(fs.readFileSync(watchlistPath, 'utf-8'));
        this.watchlist = new Set(data.symbols || []);
        logger.info(`加载观察列表: ${this.watchlist.size} 只股票`);
      } catch (error) {
        logger.error('加载观察列表失败:', error);
      }
    }
  }

  /**
   * 加载缓存数据
   */
  private loadCachedData(): void {
    const cachePath = path.join(this.dataDir, 'stocks');

    if (fs.existsSync(cachePath)) {
      const files = fs.readdirSync(cachePath);

      files.forEach((file) => {
        if (file.endsWith('.json')) {
          const symbol = file.replace('.json', '');
          const filePath = path.join(cachePath, file);

          try {
            const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
            this.cache.set(symbol, {
              data: data,
              timestamp: Date.now(),
              expiresIn: this.CACHE_DURATION,
            });
          } catch (error) {
            logger.error(`加载股票数据失败 ${file}:`, error);
          }
        }
      });

      logger.info(`加载缓存数据: ${this.cache.size} 只股票`);
    }
  }

  /**
   * 保存股票数据
   */
  async saveStockData(stockInfo: StockInfo): Promise<void> {
    const symbol = stockInfo.symbol;
    const cachePath = path.join(this.dataDir, 'stocks');

    // 确保目录存在
    if (!fs.existsSync(cachePath)) {
      fs.mkdirSync(cachePath, { recursive: true });
    }

    try {
      // 保存到文件
      const filePath = path.join(cachePath, `${symbol}.json`);
      fs.writeFileSync(filePath, JSON.stringify(stockInfo, null, 2));

      // 更新内存缓存
      this.cache.set(symbol, {
        data: stockInfo,
        timestamp: Date.now(),
        expiresIn: this.CACHE_DURATION,
      });

      logger.debug(`已保存股票 ${symbol} (${stockInfo.name}) 的数据`);
    } catch (error) {
      logger.error(`保存股票 ${symbol} 数据失败:`, error);
      throw error;
    }
  }

  /**
   * 获取股票数据
   */
  async getStockData(symbol: string, useCache: boolean = true): Promise<StockInfo | null> {
    // 检查缓存
    if (useCache) {
      const cached = this.cache.get(symbol);

      if (cached) {
        const now = Date.now();
        if (now - cached.timestamp < cached.expiresIn) {
          logger.debug(`从缓存获取股票 ${symbol} 的数据`);
          return cached.data;
        } else {
          logger.debug(`股票 ${symbol} 的缓存已过期`);
          this.cache.delete(symbol);
        }
      }
    }

    // 从文件加载
    const filePath = path.join(this.dataDir, 'stocks', `${symbol}.json`);

    if (fs.existsSync(filePath)) {
      try {
        const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));

        // 更新缓存
        this.cache.set(symbol, {
          data: data,
          timestamp: Date.now(),
          expiresIn: this.CACHE_DURATION,
        });

        logger.debug(`从文件获取股票 ${symbol} 的数据`);
        return data;
      } catch (error) {
        logger.error(`读取股票 ${symbol} 数据失败:`, error);
      }
    }

    return null;
  }

  /**
   * 获取所有股票代码
   */
  async getAllSymbols(): Promise<string[]> {
    const symbols: string[] = [];

    // 从观察列表获取
    this.watchlist.forEach((symbol) => {
      symbols.push(symbol);
    });

    // 从缓存获取
    this.cache.forEach((_, symbol) => {
      if (!symbols.includes(symbol)) {
        symbols.push(symbol);
      }
    });

    return symbols;
  }

  /**
   * 添加到观察列表
   */
  async addToWatchlist(symbols: string[]): Promise<void> {
    symbols.forEach((symbol) => {
      this.watchlist.add(symbol);
    });

    await this.saveWatchlist();
    logger.info(`已添加 ${symbols.length} 只股票到观察列表`);
  }

  /**
   * 从观察列表移除
   */
  async removeFromWatchlist(symbols: string[]): Promise<void> {
    symbols.forEach((symbol) => {
      this.watchlist.delete(symbol);
    });

    await this.saveWatchlist();
    logger.info(`已从观察列表移除 ${symbols.length} 只股票`);
  }

  /**
   * 保存观察列表
   */
  private async saveWatchlist(): Promise<void> {
    const watchlistPath = path.join(this.dataDir, 'watchlist.json');

    try {
      const data = {
        symbols: Array.from(this.watchlist),
        updatedAt: new Date().toISOString(),
      };

      fs.writeFileSync(watchlistPath, JSON.stringify(data, null, 2));
    } catch (error) {
      logger.error('保存观察列表失败:', error);
    }
  }

  /**
   * 获取观察列表
   */
  async getWatchlist(): Promise<string[]> {
    return Array.from(this.watchlist);
  }

  /**
   * 批量获取股票数据
   */
  async getBatchData(symbols: string[]): Promise<Map<string, StockInfo>> {
    const result = new Map<string, StockInfo>();

    for (const symbol of symbols) {
      const data = await this.getStockData(symbol);
      if (data) {
        result.set(symbol, data);
      }
    }

    return result;
  }

  /**
   * 获取所有数据（用于备份或同步）
   */
  async getAllData(): Promise<StockInfo[]> {
    const stocks: StockInfo[] = [];

    for (const symbol of this.cache.keys()) {
      const data = await this.getStockData(symbol);
      if (data) {
        stocks.push(data);
      }
    }

    return stocks;
  }

  /**
   * 导入数据
   */
  async importData(stocks: StockInfo[]): Promise<{ success: number; failed: number }> {
    let success = 0;
    let failed = 0;

    for (const stock of stocks) {
      try {
        await this.saveStockData(stock);
        success++;
      } catch (error) {
        logger.error(`导入股票 ${stock.symbol} 失败:`, error);
        failed++;
      }
    }

    return { success, failed };
  }

  /**
   * 导出数据
   */
  async exportData(): Promise<StockInfo[]> {
    return this.getAllData();
  }

  /**
   * 删除股票数据
   */
  async deleteStockData(symbol: string): Promise<boolean> {
    // 从缓存删除
    this.cache.delete(symbol);

    // 从观察列表删除
    this.watchlist.delete(symbol);

    // 从文件删除
    const filePath = path.join(this.dataDir, 'stocks', `${symbol}.json`);

    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      logger.info(`已删除股票 ${symbol} 的数据`);
      return true;
    }

    return false;
  }

  /**
   * 清空所有数据
   */
  async clearAllData(): Promise<void> {
    // 清空缓存
    this.cache.clear();

    // 清空观察列表
    this.watchlist.clear();

    // 删除文件
    const stocksPath = path.join(this.dataDir, 'stocks');
    if (fs.existsSync(stocksPath)) {
      fs.rmSync(stocksPath, { recursive: true, force: true });
    }

    // 重建空目录
    fs.mkdirSync(stocksPath, { recursive: true });

    logger.info('已清空所有数据');
  }

  /**
   * 获取存储统计信息
   */
  getStatistics(): {
    cachedStocks: number;
    watchlistSize: number;
    cacheSize: string;
  } {
    let cacheSize = 0;
    this.cache.forEach((entry) => {
      cacheSize += JSON.stringify(entry.data).length;
    });

    return {
      cachedStocks: this.cache.size,
      watchlistSize: this.watchlist.size,
      cacheSize: this.formatBytes(cacheSize),
    };
  }

  /**
   * 格式化字节大小
   */
  private formatBytes(bytes: number): string {
    if (bytes === 0) return '0 Bytes';

    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));

    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  /**
   * 检查缓存健康状态
   */
  async checkHealth(): Promise<{
    healthy: boolean;
    issues: string[];
  }> {
    const issues: string[] = [];

    // 检查数据目录
    if (!fs.existsSync(this.dataDir)) {
      issues.push('数据目录不存在');
    }

    // 检查缓存一致性
    const cacheKeys = Array.from(this.cache.keys());
    for (const symbol of cacheKeys) {
      const entry = this.cache.get(symbol);
      if (!entry || !entry.data) {
        issues.push(`股票 ${symbol} 缓存数据异常`);
      }
    }

    return {
      healthy: issues.length === 0,
      issues,
    };
  }
}

export default DataStoreService;
