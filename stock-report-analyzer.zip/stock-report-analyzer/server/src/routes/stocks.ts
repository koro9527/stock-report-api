// 股票数据API路由
import { Router, Request, Response } from 'express';
import THSScraperService from '../services/thsScraper';
import DataStoreService from '../services/dataStore';
import SchedulerService from '../services/scheduler';
import logger from '../utils/logger';

const router = Router();
const scraper = new THSScraperService();
const dataStore = new DataStoreService();
const scheduler = new SchedulerService();

/**
 * 获取股票数据
 * GET /api/stocks/:symbol
 */
router.get('/:symbol', async (req: Request, res: Response) => {
  try {
    const { symbol } = req.params;
    const useCache = req.query.cache !== 'false';

    logger.info(`获取股票数据: ${symbol}, 使用缓存: ${useCache}`);

    // 尝试从缓存获取
    let stockData = await dataStore.getStockData(symbol, useCache);

    // 如果没有缓存且允许获取新数据
    if (!stockData && req.query.fetch === 'true') {
      logger.info(`缓存未命中，从同花顺获取数据: ${symbol}`);
      stockData = await scraper.getCompleteStockData(symbol, { forceUpdate: true });

      if (stockData) {
        await dataStore.saveStockData(stockData);
        logger.info(`已保存股票 ${symbol} 的新数据`);
      }
    }

    if (stockData) {
      res.json({
        success: true,
        data: stockData,
        timestamp: new Date().toISOString(),
      });
    } else {
      res.status(404).json({
        success: false,
        error: `未找到股票 ${symbol} 的数据`,
        timestamp: new Date().toISOString(),
      });
    }
  } catch (error) {
    logger.error(`获取股票数据失败: ${req.params.symbol}`, error);
    res.status(500).json({
      success: false,
      error: '获取股票数据失败',
      timestamp: new Date().toISOString(),
    });
  }
});

/**
 * 搜索股票
 * GET /api/stocks/search?q=keyword
 */
router.get('/search/:keyword', async (req: Request, res: Response) => {
  try {
    const { keyword } = req.params;
    logger.info(`搜索股票: ${keyword}`);

    const results = await scraper.searchStocks(keyword);

    res.json({
      success: true,
      data: results,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    logger.error(`搜索股票失败: ${req.params.keyword}`, error);
    res.status(500).json({
      success: false,
      error: '搜索股票失败',
      timestamp: new Date().toISOString(),
    });
  }
});

/**
 * 获取所有股票列表
 * GET /api/stocks/list
 */
router.get('/list/all', async (req: Request, res: Response) => {
  try {
    const symbols = await dataStore.getAllSymbols();
    const stocks = await dataStore.getBatchData(symbols);

    const stockList = Array.from(stocks.values()).map((stock) => ({
      symbol: stock.symbol,
      name: stock.name,
      industry: stock.industry,
      lastUpdated: stock.lastUpdated,
    }));

    res.json({
      success: true,
      data: stockList,
      total: stockList.length,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    logger.error('获取股票列表失败', error);
    res.status(500).json({
      success: false,
      error: '获取股票列表失败',
      timestamp: new Date().toISOString(),
    });
  }
});

/**
 * 从同花顺获取股票数据
 * POST /api/stocks/fetch
 * Body: { symbols: string[] }
 */
router.post('/fetch', async (req: Request, res: Response) => {
  try {
    const { symbols } = req.body;

    if (!symbols || !Array.isArray(symbols) || symbols.length === 0) {
      return res.status(400).json({
        success: false,
        error: '请提供股票代码列表',
        timestamp: new Date().toISOString(),
      });
    }

    logger.info(`从同花顺获取数据: ${symbols.join(', ')}`);

    const results = {
      success: 0,
      failed: 0,
      stocks: [] as { symbol: string; name?: string; error?: string }[],
    };

    for (const symbol of symbols) {
      try {
        const stockData = await scraper.getCompleteStockData(symbol, { forceUpdate: true });

        if (stockData) {
          await dataStore.saveStockData(stockData);
          results.success++;
          results.stocks.push({
            symbol,
            name: stockData.name,
          });
          logger.info(`成功获取股票 ${symbol} (${stockData.name}) 的数据`);
        } else {
          results.failed++;
          results.stocks.push({
            symbol,
            error: '获取数据失败',
          });
          logger.warn(`获取股票 ${symbol} 数据失败`);
        }

        // 避免请求过快
        await new Promise((resolve) => setTimeout(resolve, 2000));
      } catch (error) {
        results.failed++;
        results.stocks.push({
          symbol,
          error: error instanceof Error ? error.message : '未知错误',
        });
        logger.error(`获取股票 ${symbol} 数据时出错:`, error);
      }
    }

    res.json({
      success: true,
      data: results,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    logger.error('批量获取股票数据失败', error);
    res.status(500).json({
      success: false,
      error: '批量获取股票数据失败',
      timestamp: new Date().toISOString(),
    });
  }
});

/**
 * 手动更新单只股票
 * POST /api/stocks/update/:symbol
 */
router.post('/update/:symbol', async (req: Request, res: Response) => {
  try {
    const { symbol } = req.params;
    logger.info(`手动更新股票: ${symbol}`);

    const success = await scheduler.updateSingleStock(symbol);

    if (success) {
      res.json({
        success: true,
        message: `股票 ${symbol} 更新成功`,
        timestamp: new Date().toISOString(),
      });
    } else {
      res.status(500).json({
        success: false,
        error: `股票 ${symbol} 更新失败`,
        timestamp: new Date().toISOString(),
      });
    }
  } catch (error) {
    logger.error(`更新股票失败: ${req.params.symbol}`, error);
    res.status(500).json({
      success: false,
      error: '更新股票失败',
      timestamp: new Date().toISOString(),
    });
  }
});

/**
 * 添加股票到观察列表
 * POST /api/stocks/watchlist
 * Body: { symbols: string[] }
 */
router.post('/watchlist', async (req: Request, res: Response) => {
  try {
    const { symbols } = req.body;

    if (!symbols || !Array.isArray(symbols) || symbols.length === 0) {
      return res.status(400).json({
        success: false,
        error: '请提供股票代码列表',
        timestamp: new Date().toISOString(),
      });
    }

    await dataStore.addToWatchlist(symbols);

    res.json({
      success: true,
      message: `已添加 ${symbols.length} 只股票到观察列表`,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    logger.error('添加到观察列表失败', error);
    res.status(500).json({
      success: false,
      error: '添加到观察列表失败',
      timestamp: new Date().toISOString(),
    });
  }
});

/**
 * 从观察列表移除
 * DELETE /api/stocks/watchlist
 * Body: { symbols: string[] }
 */
router.delete('/watchlist', async (req: Request, res: Response) => {
  try {
    const { symbols } = req.body;

    if (!symbols || !Array.isArray(symbols) || symbols.length === 0) {
      return res.status(400).json({
        success: false,
        error: '请提供股票代码列表',
        timestamp: new Date().toISOString(),
      });
    }

    await dataStore.removeFromWatchlist(symbols);

    res.json({
      success: true,
      message: `已从观察列表移除 ${symbols.length} 只股票`,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    logger.error('从观察列表移除失败', error);
    res.status(500).json({
      success: false,
      error: '从观察列表移除失败',
      timestamp: new Date().toISOString(),
    });
  }
});

/**
 * 获取观察列表
 * GET /api/stocks/watchlist
 */
router.get('/list/watchlist', async (req: Request, res: Response) => {
  try {
    const watchlist = await dataStore.getWatchlist();
    const stocks = await dataStore.getBatchData(watchlist);

    const stockList = Array.from(stocks.values()).map((stock) => ({
      symbol: stock.symbol,
      name: stock.name,
      industry: stock.industry,
      lastUpdated: stock.lastUpdated,
    }));

    res.json({
      success: true,
      data: stockList,
      total: stockList.length,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    logger.error('获取观察列表失败', error);
    res.status(500).json({
      success: false,
      error: '获取观察列表失败',
      timestamp: new Date().toISOString(),
    });
  }
});

/**
 * 删除股票数据
 * DELETE /api/stocks/:symbol
 */
router.delete('/:symbol', async (req: Request, res: Response) => {
  try {
    const { symbol } = req.params;
    logger.info(`删除股票数据: ${symbol}`);

    const deleted = await dataStore.deleteStockData(symbol);

    if (deleted) {
      res.json({
        success: true,
        message: `已删除股票 ${symbol} 的数据`,
        timestamp: new Date().toISOString(),
      });
    } else {
      res.status(404).json({
        success: false,
        error: `未找到股票 ${symbol} 的数据`,
        timestamp: new Date().toISOString(),
      });
    }
  } catch (error) {
    logger.error(`删除股票数据失败: ${req.params.symbol}`, error);
    res.status(500).json({
      success: false,
      error: '删除股票数据失败',
      timestamp: new Date().toISOString(),
    });
  }
});

/**
 * 获取存储统计信息
 * GET /api/stocks/stats
 */
router.get('/stats/all', async (req: Request, res: Response) => {
  try {
    const stats = dataStore.getStatistics();
    const health = await dataStore.checkHealth();

    res.json({
      success: true,
      data: {
        ...stats,
        ...health,
      },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    logger.error('获取统计信息失败', error);
    res.status(500).json({
      success: false,
      error: '获取统计信息失败',
      timestamp: new Date().toISOString(),
    });
  }
});

export default router;
