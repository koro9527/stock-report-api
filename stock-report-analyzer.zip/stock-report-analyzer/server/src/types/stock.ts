// 股票财务数据类型定义

export interface FinancialMetrics {
  // 资产类
  totalAssets: number;          // 总资产（元）
  totalLiabilities: number;      // 总负债（元）
  currencyFunds: number;         // 货币资金（元）
  tradingAssets: number;         // 交易性金融资产（元）
  receivables: number;           // 应收账款（元）
  contractAssets: number;        // 合同资产（元）
  inventory: number;             // 存货（元）
  goodwill: number;              // 商誉（元）
  fixedAssets: number;           // 固定资产（元）
  constructionInProgress: number; // 在建工程（元）
  investmentAssets: number;       // 投资类资产（元）

  // 负债类
  advanceReceivables: number;    // 预收账款（元）
  payableAccounts: number;        // 应付账款（元）
  interestLiabilities: number;   // 有息负债（元）

  // 利润类
  revenue: number;               // 营业收入（元）
  netProfit: number;             // 净利润（元）

  // 现金流
  cashFromOps: number;           // 经营活动现金流（元）
  cashFromInvesting: number;     // 投资活动现金流（元）
  cashFromFinancing: number;     // 筹资活动现金流（元）

  // 收益率
  roe: number;                  // 净资产收益率（%）
  netProfitMargin: number;       // 净利润率（%）
  grossProfitMargin: number;     // 毛利率（%）

  // 成长性
  revenueGrowth: number;         // 营收增长率（%）
  netProfitGrowth: number;       // 净利润增长率（%）
  totalAssetsGrowth: number;     // 总资产增长率（%）

  // 偿债能力
  currentRatio: number;          // 流动比率
  quickRatio: number;             // 速动比率
  debtAssetRatio: number;        // 资产负债率（%）

  // 运营效率
  assetTurnover: number;          // 总资产周转率
  inventoryTurnover: number;      // 存货周转率
  receivableTurnover: number;     // 应收账款周转率

  // 其他
  totalEquity: number;           // 股东权益（元）
  basicEPS: number;              // 每股收益（元）
  dilutedEPS: number;             // 稀释每股收益（元）
}

export interface YearlyFinancialData {
  year: number;
  metrics: FinancialMetrics;
  reportDate?: string;           // 报告发布日期
  reportType?: string;           // 报告类型（年报/季报）
}

export interface StockInfo {
  symbol: string;               // 股票代码
  name: string;                 // 股票名称
  industry: string;             // 所属行业
  area: string;                  // 所在地区
  listDate: string;             // 上市日期
  market: string;               // 市场类型（主板/创业板/中小板）
  exchange: string;            // 交易所
  currency: string;             // 币种
  historicalData: YearlyFinancialData[]; // 历史财务数据
  lastUpdated: string;          // 最后更新时间
  dataSource: string;            // 数据来源
}

export interface StockSearchResult {
  symbol: string;
  name: string;
  pinyin?: string;
  market?: string;
  exchange?: string;
}

export interface FetchOptions {
  forceUpdate?: boolean;         // 强制更新（忽略缓存）
  years?: number[];             // 指定年份
  detailed?: boolean;            // 获取详细数据
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  timestamp: string;
}

export interface StockAnalysisResult {
  symbol: string;
  name: string;
  overallScore: number;         // 综合评分（0-100）
  riskLevel: 'low' | 'medium' | 'high'; // 风险等级
  profitability: {
    score: number;
    roe: number;
    netProfitMargin: number;
    trend: 'up' | 'down' | 'stable';
  };
  growth: {
    score: number;
    revenueGrowth: number;
    netProfitGrowth: number;
    trend: 'up' | 'down' | 'stable';
  };
  stability: {
    score: number;
    debtAssetRatio: number;
    currentRatio: number;
    trend: 'up' | 'down' | 'stable';
  };
  efficiency: {
    score: number;
    assetTurnover: number;
    inventoryTurnover: number;
  };
  recommendations: string[];     // 分析建议
  warnings: string[];           // 风险警告
}

export interface DataSourceConfig {
  name: string;
  baseUrl: string;
  timeout: number;
  retryAttempts: number;
  retryDelay: number;
  rateLimitDelay: number;
}
